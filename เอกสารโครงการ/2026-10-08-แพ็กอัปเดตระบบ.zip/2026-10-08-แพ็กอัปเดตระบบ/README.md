# แพ็กอัปเดต 2026-10-08: โหมดอัตโนมัติ + ชดเชยเซนเซอร์ + ข้อสอบ 32 ข้อ

โครงสร้างในแพ็กตรงกับ htdocs/handysense/ คัดลอกทับไฟล์ที่มีชื่อเดียวกัน **สำรองไฟล์เดิมก่อนทุกไฟล์**

## ไฟล์เซิร์ฟเวอร์ (leqs-workshop/)
| ไฟล์ | สถานะ | หมายเหตุ |
|---|---|---|
| api/api.php | แก้ไข (ทับ) | เพิ่ม endpoint get_rules, save_rule, delete_rule, set_rules_enabled, get_calibration, save_calibration |
| api/rules.php | ใหม่ | กฎอัตโนมัติ + ชดเชยเซนเซอร์ |
| api/automation.php | เดิม (ตัวจับเวลา ตารางเวลา audit โปรไฟล์) | ต้องมีคู่กับ api.php |
| includes/auto_engine_panel.php | ใหม่ | แผงใช้ร่วมกันทั้งแดชบอร์ดและมือถือ |
| includes/quiz_core.php, quiz_bank.json | ใหม่ | แกนและธนาคารข้อสอบ 32 ข้อ |
| dashboard/index.php, mobile/index.php | แก้ไข (ทับ) | เพิ่มการ include แผงโหมดอัตโนมัติหนึ่งบล็อก |
| pages/assessment_pre.php, assessment_post.php | แก้ไข (ทับ) | ใช้ข้อสอบ 32 ข้อ |
| pages/quiz_save.php | ใหม่ | บันทึกผลและส่งออก CSV |

**ข้อควรระวัง:** api.php ใน htdocs ตอนตรวจ (ขนาด 98,146 ไบต์) เป็นรุ่นเก่ากว่ารุ่นในแพ็กนี้ (ไม่มีตัวจับเวลา/ตารางเวลา/การเขียนไฟล์แบบอะตอมมิก) ไฟล์ในแพ็กรวมของเดิมทั้งหมดแล้ว แต่ต้องอัปโหลด automation.php คู่กันเสมอ

หลังคัดลอก:
1. โฟลเดอร์ data/ ต้องให้ PHP เขียนได้ (ไฟล์ใหม่: rules.json, calibration.json, quiz_results.json, quiz.lock)
2. เปิด dashboard/ และ mobile/ ดูแผง "โหมดอัตโนมัติ" ใต้ส่วนกฎเดิม
3. ถ้าตั้ง data/api_key.txt ไว้ แผงจะแนบคีย์ให้เอง (คีย์อยู่ในซอร์สหน้าเว็บ ควรป้องกันโฟลเดอร์ด้วย Basic Auth)
4. ทดสอบ: ตั้งกฎจากตัวอย่าง เปิดสวิตช์รวม ดูรายการ "กฎ …" ที่บันทึกการใช้งาน
5. ยกเลิก: คืนไฟล์ที่สำรองไว้ แล้วลบ rules.php ได้ (api.php เดิมไม่เรียกไฟล์นี้)

## แอป Flutter (handysense_flutter/lib/)
ไฟล์ใหม่: data/models/rule_models.dart, presentation/screens/rules_screen.dart, calibration_screen.dart
ไฟล์แก้ไข: data/services/api_service.dart, data/repositories/telemetry_repository.dart, presentation/screens/control_screen.dart, presentation/widgets/common.dart
- common.dart: แก้ลำดับวันให้ตรงเซิร์ฟเวอร์ (0 = อาทิตย์) ของเดิมเรียงจันทร์ก่อน ทำให้ตารางเวลาที่เลือก "จ." ไปทำงานวันอาทิตย์
- **ยังไม่ได้คอมไพล์** (ไม่มี Flutter SDK) ให้รัน `flutter pub get`, `flutter analyze` แล้วส่งข้อผิดพลาดกลับมา
