import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/rule_models.dart';
import '../view_models/telemetry_view_model.dart';
import '../widgets/common.dart';

/// ชดเชยความคลาดเคลื่อนเซนเซอร์: ค่าที่ใช้ = ค่าดิบ × อัตราส่วน + ค่าชดเชย
/// ใช้กับการแสดงผล กฎอัตโนมัติ การแจ้งเตือน และประวัติ (VPD คำนวณใหม่จากอุณหภูมิ/ความชื้นที่ชดเชยแล้ว)
class CalibrationScreen extends StatefulWidget {
  const CalibrationScreen({super.key});
  @override
  State<CalibrationScreen> createState() => _CalibrationScreenState();
}

class _CalibrationScreenState extends State<CalibrationScreen> {
  CalibrationState? _state;
  String? _error;
  bool _loading = true;
  final Map<String, TextEditingController> _off = {};
  final Map<String, TextEditingController> _gain = {};
  final Map<String, TextEditingController> _ref = {};

  @override
  void initState() {
    super.initState();
    for (final k in calibrationSensors) {
      _off[k] = TextEditingController();
      _gain[k] = TextEditingController();
      _ref[k] = TextEditingController();
    }
    _load();
  }

  @override
  void dispose() {
    for (final m in [_off, _gain, _ref]) {
      for (final c in m.values) {
        c.dispose();
      }
    }
    super.dispose();
  }

  static String _n(double v) => double.parse(v.toStringAsFixed(4)).toString();

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final s = await context.read<TelemetryViewModel>().repository.getCalibration();
      if (!mounted) return;
      setState(() {
        _state = s;
        for (final k in calibrationSensors) {
          _off[k]!.text = _n(s.cal[k]!.offset);
          _gain[k]!.text = _n(s.cal[k]!.gain);
        }
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  double _o(String k) => double.tryParse(_off[k]!.text.trim()) ?? 0;
  double _g(String k) => double.tryParse(_gain[k]!.text.trim()) ?? 1;

  void _fromRef(String k) {
    final ref = double.tryParse(_ref[k]!.text.trim());
    final raw = _state?.raw[k];
    if (ref == null || raw == null) {
      showAppSnack(context, 'ต้องมีค่าอ้างอิงและค่าดิบปัจจุบันจากบอร์ด', error: true);
      return;
    }
    setState(() => _off[k]!.text = _n(ref - raw * _g(k)));
  }

  Future<void> _save({bool reset = false}) async {
    final cal = <String, Map<String, double>>{
      for (final k in calibrationSensors)
        k: reset ? {'offset': 0.0, 'gain': 1.0} : {'offset': _o(k), 'gain': _g(k)},
    };
    final r = await context.read<TelemetryViewModel>().repository.saveCalibration(cal);
    if (!mounted) return;
    showAppSnack(context, r.ok ? (reset ? 'คืนค่าเริ่มต้นแล้ว' : 'บันทึกค่าชดเชยแล้ว') : r.message, error: !r.ok);
    if (r.ok) _load();
  }

  @override
  Widget build(BuildContext context) {
    final st = _state;
    return Scaffold(
      backgroundColor: AppColors.scaffoldDark,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0C1322),
        title: Text('ชดเชยค่าเซนเซอร์', style: thText(18, weight: FontWeight.w700, color: AppColors.textWhite)),
      ),
      body: _loading && st == null
          ? const Center(child: CircularProgressIndicator())
          : st == null
              ? Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Text(_error ?? 'โหลดไม่สำเร็จ', style: thText(14)),
                    const SizedBox(height: 12),
                    FilledButton(onPressed: _load, child: Text('ลองใหม่', style: thText(14, weight: FontWeight.w700, color: Colors.black))),
                  ]),
                )
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Text(
                      'วัดด้วยเครื่องมืออ้างอิง (เทอร์โมมิเตอร์ ความชื้นมาตรฐาน หรือชั่งดินหาความชื้นจริง) '
                      'แล้วกรอก "ค่าอ้างอิง" กด "คำนวณ" ระบบจะตั้งค่าชดเชยให้ ณ จุดนั้น',
                      style: thText(13, color: AppColors.textMuted),
                    ),
                    const SizedBox(height: 12),
                    for (final k in calibrationSensors) ...[
                      AppCard(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            Expanded(child: Text(ruleSensors[k]!.$1, style: thText(15, weight: FontWeight.w700, color: AppColors.textWhite))),
                            Text(
                              'ดิบ ${st.raw[k]?.toStringAsFixed(2) ?? '-'} → ใช้ '
                              '${st.raw[k] == null ? '-' : (st.raw[k]! * _g(k) + _o(k)).toStringAsFixed(2)} ${ruleSensors[k]!.$2}',
                              style: thText(12.5, weight: FontWeight.w600, color: AppColors.neonGreen),
                            ),
                          ]),
                          const SizedBox(height: 8),
                          Row(children: [
                            Expanded(child: _field(_off[k]!, 'ค่าชดเชย (+/−)')),
                            const SizedBox(width: 8),
                            Expanded(child: _field(_gain[k]!, 'อัตราส่วน (0.5–2)')),
                          ]),
                          const SizedBox(height: 8),
                          Row(children: [
                            Expanded(child: _field(_ref[k]!, 'ค่าอ้างอิงที่วัดได้จริง')),
                            const SizedBox(width: 8),
                            FilledButton(
                              onPressed: () => _fromRef(k),
                              style: FilledButton.styleFrom(minimumSize: const Size(88, 48)),
                              child: Text('คำนวณ', style: thText(14, weight: FontWeight.w800, color: Colors.black)),
                            ),
                          ]),
                        ]),
                      ),
                      const SizedBox(height: 10),
                    ],
                    Row(children: [
                      Expanded(
                        child: FilledButton(
                          onPressed: () => _save(),
                          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                          child: Text('บันทึกค่าชดเชย', style: thText(15, weight: FontWeight.w800, color: Colors.black)),
                        ),
                      ),
                      const SizedBox(width: 10),
                      OutlinedButton(
                        onPressed: () => _save(reset: true),
                        style: OutlinedButton.styleFrom(minimumSize: const Size(0, 52)),
                        child: Text('คืนค่าเริ่มต้น', style: thText(14, weight: FontWeight.w700)),
                      ),
                    ]),
                    const SizedBox(height: 24),
                  ],
                ),
    );
  }

  Widget _field(TextEditingController c, String label) => TextField(
        controller: c,
        keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
        style: thText(14, color: AppColors.textWhite),
        onChanged: (_) => setState(() {}),
        decoration: InputDecoration(isDense: true, labelText: label, labelStyle: thText(12, color: AppColors.textMuted)),
      );
}
