import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/rule_models.dart';
import '../view_models/telemetry_view_model.dart';
import '../widgets/common.dart';

/// กฎอัตโนมัติตามเงื่อนไข (ความชื้นดิน อุณหภูมิ ความชื้นอากาศ VPD ฯลฯ) + ช่วงเวลา/วัน
/// ประมวลผลที่เซิร์ฟเวอร์ ทำงานแม้ปิดแอป แต่ต้องมีบอร์ดออนไลน์
class RulesScreen extends StatefulWidget {
  const RulesScreen({super.key});
  @override
  State<RulesScreen> createState() => _RulesScreenState();
}

class _RulesScreenState extends State<RulesScreen> {
  RulesState? _state;
  String? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final s = await context.read<TelemetryViewModel>().repository.getRules();
      if (!mounted) return;
      setState(() => _state = s);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _master(bool v) async {
    final r = await context.read<TelemetryViewModel>().repository.setRulesEnabled(v);
    if (!mounted) return;
    if (!r.ok) showAppSnack(context, r.message, error: true);
    _load();
  }

  Future<void> _edit([RuleItem? item, RuleItem? preset]) async {
    final vm = context.read<TelemetryViewModel>();
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.darkCard,
      showDragHandle: true,
      builder: (_) => _RuleEditor(
        initial: item ?? preset,
        editing: item != null,
        relayNames: {for (int i = 1; i <= 4; i++) i: relayShortName(vm.relayView(i).item.name)},
      ),
    );
    if (result == null || !mounted) return;
    final r = await vm.repository.saveRule(result);
    if (!mounted) return;
    showAppSnack(context, r.ok ? 'บันทึกกฎแล้ว' : r.message, error: !r.ok);
    if (r.ok) _load();
  }

  Future<void> _toggle(RuleItem r, bool v) async {
    final res = await context.read<TelemetryViewModel>().repository.saveRule(r.toJson(enabledOverride: v));
    if (!mounted) return;
    if (!res.ok) showAppSnack(context, res.message, error: true);
    _load();
  }

  Future<void> _delete(RuleItem r) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.darkCard,
        title: Text('ลบกฎนี้?', style: thText(17, weight: FontWeight.w700, color: AppColors.textWhite)),
        content: Text(r.name.isEmpty ? r.id : r.name, style: thText(14)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('ยกเลิก', style: thText(14))),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.alertRed),
            child: Text('ลบ', style: thText(14, weight: FontWeight.w700, color: Colors.white)),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final res = await context.read<TelemetryViewModel>().repository.deleteRule(r.id);
    if (!mounted) return;
    showAppSnack(context, res.ok ? 'ลบแล้ว' : res.message, error: !res.ok);
    _load();
  }

  static const _presets = <String, RuleItem>{
    'ดินแห้งแล้วรดน้ำ': RuleItem(
      id: '', name: 'รดน้ำเมื่อดินแห้ง', enabled: true, relay: 1, turnOn: true, matchAny: false,
      conditions: [RuleCondition(sensor: 'soil_moisture', op: '<', value: 40)],
      stop: RuleCondition(sensor: 'soil_moisture', op: '>=', value: 60),
      durationMin: 10, holdSec: 60, cooldownMin: 30, days: [0, 1, 2, 3, 4, 5, 6],
    ),
    'VPD สูงแล้วพ่นหมอก': RuleItem(
      id: '', name: 'พ่นหมอกเมื่อ VPD สูง', enabled: true, relay: 4, turnOn: true, matchAny: false,
      conditions: [RuleCondition(sensor: 'vpd', op: '>', value: 1.6)],
      stop: RuleCondition(sensor: 'vpd', op: '<=', value: 1.2),
      durationMin: 3, holdSec: 60, cooldownMin: 15, days: [0, 1, 2, 3, 4, 5, 6],
    ),
    'ร้อนและแห้ง (06:00–18:00)': RuleItem(
      id: '', name: 'ร้อนและแห้ง พ่นหมอก', enabled: true, relay: 4, turnOn: true, matchAny: false,
      conditions: [
        RuleCondition(sensor: 'temperature', op: '>', value: 35),
        RuleCondition(sensor: 'humidity', op: '<', value: 55),
      ],
      durationMin: 5, holdSec: 60, cooldownMin: 20, windowStart: '06:00', windowEnd: '18:00',
      days: [0, 1, 2, 3, 4, 5, 6],
    ),
  };

  Future<void> _pickPreset() async {
    final key = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppColors.darkCard,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.edit_note_rounded, color: AppColors.neonCyan),
            title: Text('เริ่มจากกฎว่าง', style: thText(15, weight: FontWeight.w700, color: AppColors.textWhite)),
            onTap: () => Navigator.pop(ctx, ''),
          ),
          for (final k in _presets.keys)
            ListTile(
              leading: const Icon(Icons.auto_awesome_rounded, color: AppColors.neonGreen),
              title: Text(k, style: thText(15, weight: FontWeight.w600, color: AppColors.textWhite)),
              subtitle: Text(_presets[k]!.conditions.map((c) => c.text).join(' และ '), style: thText(12.5, color: AppColors.textMuted)),
              onTap: () => Navigator.pop(ctx, k),
            ),
        ]),
      ),
    );
    if (key == null || !mounted) return;
    _edit(null, key.isEmpty ? null : _presets[key]);
  }

  String _daysText(List<int> d) {
    if (d.length == 7) return 'ทุกวัน';
    final s = [...d]..sort();
    return s.map((e) => thaiDays[e.clamp(0, 6)]).join(' ');
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<TelemetryViewModel>();
    final st = _state;
    return Scaffold(
      backgroundColor: AppColors.scaffoldDark,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0C1322),
        title: Text('กฎอัตโนมัติ', style: thText(18, weight: FontWeight.w700, color: AppColors.textWhite)),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _pickPreset,
        backgroundColor: AppColors.neonCyan,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add_rounded),
        label: Text('เพิ่มกฎ', style: thText(14, weight: FontWeight.w700, color: Colors.black)),
      ),
      body: _loading && st == null
          ? const Center(child: CircularProgressIndicator())
          : st == null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.cloud_off_rounded, size: 40, color: AppColors.alertRed),
                      const SizedBox(height: 10),
                      Text(_error ?? 'โหลดไม่สำเร็จ', style: thText(14), textAlign: TextAlign.center),
                      const SizedBox(height: 12),
                      FilledButton(onPressed: _load, child: Text('ลองใหม่', style: thText(14, weight: FontWeight.w700, color: Colors.black))),
                    ]),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
                    children: [
                      AppCard(
                        borderColor: st.enabled ? AppColors.neonGreen.withAlpha(120) : AppColors.borderDark,
                        child: Row(children: [
                          Icon(Icons.smart_toy_rounded, color: st.enabled ? AppColors.neonGreen : AppColors.textDim),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('ระบบกฎอัตโนมัติ', style: thText(16, weight: FontWeight.w700, color: AppColors.textWhite)),
                              Text(st.enabled ? 'เปิดอยู่ — ทำงานเมื่อบอร์ดออนไลน์' : 'ปิดอยู่ — กฎทั้งหมดจะไม่ทำงาน',
                                  style: thText(12.5, color: AppColors.textMuted)),
                            ]),
                          ),
                          Switch(value: st.enabled, onChanged: _master),
                        ]),
                      ),
                      const SizedBox(height: 12),
                      if (st.rules.isEmpty)
                        Padding(
                          padding: const EdgeInsets.all(32),
                          child: Column(children: [
                            const Icon(Icons.rule_rounded, size: 48, color: AppColors.textDim),
                            const SizedBox(height: 10),
                            Text('ยังไม่มีกฎ', style: thText(16, weight: FontWeight.w700, color: AppColors.textWhite)),
                            Text('กด "เพิ่มกฎ" แล้วเลือกตัวอย่างสำเร็จรูป', style: thText(13, color: AppColors.textMuted)),
                          ]),
                        ),
                      for (final r in st.rules) ...[
                        AppCard(
                          borderColor: r.running ? AppColors.neonGreen : (r.enabled ? AppColors.borderGlow : AppColors.borderDark),
                          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Expanded(
                              child: InkWell(
                                onTap: () => _edit(r),
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text(r.name.isEmpty ? r.id : r.name,
                                      style: thText(16, weight: FontWeight.w700,
                                          color: r.enabled ? AppColors.textWhite : AppColors.textDim)),
                                  const SizedBox(height: 2),
                                  Text(
                                    'ถ้า ${r.conditions.map((c) => c.text).join(r.matchAny ? ' หรือ ' : ' และ ')}\n'
                                    '→ ${r.turnOn ? 'เปิด' : 'ปิด'} ${relayShortName(vm.relayView(r.relay).item.name)}',
                                    style: thText(13.5, weight: FontWeight.w600),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    [
                                      if (r.turnOn && r.durationMin > 0) 'เปิด ${r.durationMin} นาที',
                                      if (r.stop != null) 'หยุดเมื่อ ${r.stop!.text}',
                                      if (r.windowStart != null) 'เวลา ${r.windowStart}–${r.windowEnd}',
                                      if (r.days.length < 7) _daysText(r.days),
                                      'คงเงื่อนไข ${r.holdSec} วิ',
                                      'พัก ${r.cooldownMin} นาที',
                                    ].join(' · '),
                                    style: thText(12, color: AppColors.textMuted),
                                  ),
                                  if (r.running)
                                    Text('กำลังทำงาน', style: thText(12.5, weight: FontWeight.w700, color: AppColors.neonGreen)),
                                ]),
                              ),
                            ),
                            Column(children: [
                              Switch(value: r.enabled, onChanged: (v) => _toggle(r, v)),
                              IconButton(
                                tooltip: 'ลบ',
                                onPressed: () => _delete(r),
                                icon: const Icon(Icons.delete_outline_rounded, color: AppColors.alertRed),
                                constraints: const BoxConstraints(minWidth: 48, minHeight: 48),
                              ),
                            ]),
                          ]),
                        ),
                        const SizedBox(height: 10),
                      ],
                      Text(
                        '"คงเงื่อนไข" กรองสัญญาณรบกวน ส่วน "พัก" กันรีเลย์ติด-ดับถี่ การสั่งเปิดต้องมีเวลาเปิดหรือเงื่อนไขหยุดเสมอ เพื่อไม่ให้เปิดค้าง',
                        style: thText(12, color: AppColors.textMuted),
                      ),
                    ],
                  ),
                ),
    );
  }
}

class _RuleEditor extends StatefulWidget {
  const _RuleEditor({required this.initial, required this.editing, required this.relayNames});
  final RuleItem? initial;
  final bool editing;
  final Map<int, String> relayNames;
  @override
  State<_RuleEditor> createState() => _RuleEditorState();
}

class _CondDraft {
  String sensor;
  String op;
  final TextEditingController value;
  _CondDraft(this.sensor, this.op, double v) : value = TextEditingController(text: _fmt(v));
  static String _fmt(double v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toString();
  double? get parsed => double.tryParse(value.text.trim());
}

class _RuleEditorState extends State<_RuleEditor> {
  late final TextEditingController _name;
  late int _relay;
  late bool _turnOn;
  late bool _any;
  late List<_CondDraft> _conds;
  late bool _useStop;
  late _CondDraft _stop;
  late int _duration;
  late int _hold;
  late int _cool;
  late bool _useWin;
  late TimeOfDay _ws;
  late TimeOfDay _we;
  late Set<int> _days;
  String? _err;

  TimeOfDay _parse(String? s, TimeOfDay d) {
    if (s == null) return d;
    final p = s.split(':');
    return TimeOfDay(hour: int.tryParse(p[0]) ?? d.hour, minute: int.tryParse(p.length > 1 ? p[1] : '0') ?? 0);
  }

  @override
  void initState() {
    super.initState();
    final r = widget.initial;
    _name = TextEditingController(text: r?.name ?? '');
    _relay = r?.relay ?? 1;
    _turnOn = r?.turnOn ?? true;
    _any = r?.matchAny ?? false;
    _conds = (r?.conditions.isNotEmpty ?? false)
        ? r!.conditions.map((c) => _CondDraft(c.sensor, c.op, c.value)).toList()
        : [_CondDraft('soil_moisture', '<', 40)];
    _useStop = r?.stop != null;
    _stop = r?.stop != null
        ? _CondDraft(r!.stop!.sensor, r.stop!.op, r.stop!.value)
        : _CondDraft('soil_moisture', '>=', 60);
    _duration = r?.durationMin ?? 5;
    _hold = r?.holdSec ?? 30;
    _cool = r?.cooldownMin ?? 10;
    _useWin = r?.windowStart != null;
    _ws = _parse(r?.windowStart, const TimeOfDay(hour: 6, minute: 0));
    _we = _parse(r?.windowEnd, const TimeOfDay(hour: 18, minute: 0));
    _days = {...(r?.days ?? [0, 1, 2, 3, 4, 5, 6])};
  }

  String _t(TimeOfDay t) => '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  Widget _condRow(_CondDraft c, {VoidCallback? onRemove}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(children: [
        Expanded(
          flex: 5,
          child: DropdownButtonFormField<String>(
            value: c.sensor,
            isExpanded: true,
            decoration: const InputDecoration(isDense: true),
            items: [
              for (final e in ruleSensors.entries)
                DropdownMenuItem(value: e.key, child: Text(e.value.$1, style: thText(13.5, color: AppColors.textWhite))),
            ],
            onChanged: (v) => setState(() => c.sensor = v ?? c.sensor),
          ),
        ),
        const SizedBox(width: 6),
        Expanded(
          flex: 3,
          child: DropdownButtonFormField<String>(
            value: c.op,
            decoration: const InputDecoration(isDense: true),
            items: [
              for (final o in ['<', '<=', '>', '>='])
                DropdownMenuItem(value: o, child: Text(o, style: thText(14, weight: FontWeight.w700, color: AppColors.textWhite))),
            ],
            onChanged: (v) => setState(() => c.op = v ?? c.op),
          ),
        ),
        const SizedBox(width: 6),
        Expanded(
          flex: 3,
          child: TextField(
            controller: c.value,
            keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
            style: thText(14, color: AppColors.textWhite),
            decoration: const InputDecoration(isDense: true),
          ),
        ),
        if (onRemove != null)
          IconButton(onPressed: onRemove, icon: const Icon(Icons.close_rounded, size: 20), tooltip: 'ลบเงื่อนไข'),
      ]),
    );
  }

  Widget _label(String s) => Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 6),
        child: Text(s, style: thText(13, color: AppColors.textMuted)),
      );

  void _save() {
    final conds = <Map<String, dynamic>>[];
    for (final c in _conds) {
      final v = c.parsed;
      if (v == null) {
        setState(() => _err = 'กรอกค่าเงื่อนไขให้ครบเป็นตัวเลข');
        return;
      }
      conds.add({'sensor': c.sensor, 'op': c.op, 'value': v});
    }
    Map<String, dynamic>? stop;
    if (_useStop) {
      final v = _stop.parsed;
      if (v == null) {
        setState(() => _err = 'กรอกค่าเงื่อนไขหยุดเป็นตัวเลข');
        return;
      }
      stop = {'sensor': _stop.sensor, 'op': _stop.op, 'value': v};
    }
    if (_turnOn && _duration == 0 && stop == null) {
      setState(() => _err = 'การสั่งเปิดต้องกำหนดเวลาเปิด หรือเงื่อนไขหยุด');
      return;
    }
    Navigator.pop(context, {
      if (widget.editing && (widget.initial?.id.isNotEmpty ?? false)) 'id': widget.initial!.id,
      'name': _name.text.trim(),
      'relay': _relay,
      'action': _turnOn ? 'on' : 'off',
      'logic': _any ? 'any' : 'all',
      'conditions': conds,
      if (stop != null) 'stop': stop,
      'duration': _turnOn ? _duration : 0,
      'hold_sec': _hold,
      'cooldown_min': _cool,
      if (_useWin) 'window': {'start': _t(_ws), 'end': _t(_we)},
      'days': ([..._days]..sort()),
      'enabled': widget.editing ? (widget.initial!.enabled ? 1 : 0) : 1,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 4, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(widget.editing ? 'แก้ไขกฎ' : 'เพิ่มกฎ', style: thText(18, weight: FontWeight.w700, color: AppColors.textWhite)),
          _label('ชื่อกฎ'),
          TextField(controller: _name, maxLength: 60, style: thText(14, color: AppColors.textWhite), decoration: const InputDecoration(isDense: true, counterText: '')),
          _label('รีเลย์ที่สั่ง'),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final e in widget.relayNames.entries)
              ChoiceChip(
                label: Text('${e.key}. ${e.value}', style: thText(13, weight: FontWeight.w600, color: AppColors.textWhite)),
                selected: _relay == e.key,
                onSelected: (_) => setState(() => _relay = e.key),
              ),
          ]),
          const SizedBox(height: 12),
          SegmentedButton<bool>(
            segments: [
              ButtonSegment(value: true, label: Text('สั่งเปิด', style: thText(14, weight: FontWeight.w600))),
              ButtonSegment(value: false, label: Text('สั่งปิด', style: thText(14, weight: FontWeight.w600))),
            ],
            selected: {_turnOn},
            onSelectionChanged: (v) => setState(() => _turnOn = v.first),
          ),
          _label('เมื่อเงื่อนไข'),
          SegmentedButton<bool>(
            segments: [
              ButtonSegment(value: false, label: Text('ทุกข้อ (และ)', style: thText(13, weight: FontWeight.w600))),
              ButtonSegment(value: true, label: Text('ข้อใดข้อหนึ่ง (หรือ)', style: thText(13, weight: FontWeight.w600))),
            ],
            selected: {_any},
            onSelectionChanged: (v) => setState(() => _any = v.first),
          ),
          const SizedBox(height: 10),
          for (int i = 0; i < _conds.length; i++)
            _condRow(_conds[i], onRemove: _conds.length > 1 ? () => setState(() => _conds.removeAt(i)) : null),
          if (_conds.length < 4)
            TextButton.icon(
              onPressed: () => setState(() => _conds.add(_CondDraft('temperature', '>', 35))),
              icon: const Icon(Icons.add_rounded),
              label: Text('เพิ่มเงื่อนไข', style: thText(13.5, weight: FontWeight.w600)),
            ),
          if (_turnOn) ...[
            _label(_duration == 0 ? 'ไม่จำกัดเวลาเปิด (ต้องมีเงื่อนไขหยุด)' : 'เปิดนาน $_duration นาที'),
            Slider(value: _duration.toDouble(), min: 0, max: 120, divisions: 24, label: '$_duration นาที',
                onChanged: (v) => setState(() => _duration = v.round())),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('หยุดอัตโนมัติเมื่อถึงเงื่อนไข', style: thText(14, weight: FontWeight.w600, color: AppColors.textWhite)),
              value: _useStop,
              onChanged: (v) => setState(() => _useStop = v),
            ),
            if (_useStop) _condRow(_stop),
          ],
          _label('คงเงื่อนไขนาน $_hold วินาที จึงสั่ง (กรองสัญญาณรบกวน)'),
          Slider(value: _hold.toDouble(), min: 0, max: 300, divisions: 30, label: '$_hold วิ', onChanged: (v) => setState(() => _hold = v.round())),
          _label('พักก่อนสั่งซ้ำ $_cool นาที'),
          Slider(value: _cool.toDouble(), min: 0, max: 120, divisions: 24, label: '$_cool นาที', onChanged: (v) => setState(() => _cool = v.round())),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('ทำงานเฉพาะช่วงเวลา', style: thText(14, weight: FontWeight.w600, color: AppColors.textWhite)),
            value: _useWin,
            onChanged: (v) => setState(() => _useWin = v),
          ),
          if (_useWin)
            Row(children: [
              OutlinedButton(
                onPressed: () async {
                  final t = await showTimePicker(context: context, initialTime: _ws);
                  if (t != null) setState(() => _ws = t);
                },
                child: Text('เริ่ม ${_t(_ws)}', style: thText(15, weight: FontWeight.w700, color: AppColors.textWhite)),
              ),
              const SizedBox(width: 10),
              OutlinedButton(
                onPressed: () async {
                  final t = await showTimePicker(context: context, initialTime: _we);
                  if (t != null) setState(() => _we = t);
                },
                child: Text('สิ้นสุด ${_t(_we)}', style: thText(15, weight: FontWeight.w700, color: AppColors.textWhite)),
              ),
            ]),
          _label('วันที่ทำงาน'),
          Wrap(spacing: 6, runSpacing: 6, children: [
            for (int d = 0; d < 7; d++)
              FilterChip(
                label: Text(thaiDays[d], style: thText(13, weight: FontWeight.w600, color: AppColors.textWhite)),
                selected: _days.contains(d),
                onSelected: (v) => setState(() => v ? _days.add(d) : _days.remove(d)),
              ),
          ]),
          if (_err != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_err!, style: thText(13, color: AppColors.alertRed))),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: FilledButton(
              onPressed: _days.isEmpty ? null : _save,
              child: Text('บันทึกกฎ', style: thText(16, weight: FontWeight.w800, color: Colors.black)),
            ),
          ),
        ]),
      ),
    );
  }
}
