import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../core/constants/api_constants.dart';
import '../models/farm_models.dart';
import '../models/rule_models.dart';
import '../models/telemetry_model.dart';

/// ผลลัพธ์ของคำสั่งที่ส่งไปเซิร์ฟเวอร์
class CommandResult {
  final bool ok;
  final String message;
  final Map<String, dynamic>? data;
  const CommandResult(this.ok, this.message, {this.data});
}

class ApiService {
  String _boardIp = ApiConstants.defaultBoardIp;
  int _boardPort = ApiConstants.defaultBoardPort;
  String _localApiUrl = ApiConstants.defaultLocalApiUrl;
  String _apiKey = '';

  ApiService({String? boardIp, int? boardPort, String? localApiUrl}) {
    if (boardIp != null) _boardIp = boardIp;
    if (boardPort != null) _boardPort = boardPort;
    if (localApiUrl != null) _localApiUrl = localApiUrl;
  }

  void updateConfig({required String boardIp, required int boardPort, required String localApiUrl, String? apiKey}) {
    _boardIp = boardIp;
    _boardPort = boardPort;
    _localApiUrl = localApiUrl;
    if (apiKey != null) _apiKey = apiKey;
  }

  /// header สำหรับคำสั่งที่เปลี่ยนแปลงข้อมูล (เซิร์ฟเวอร์ตรวจเมื่อมีไฟล์ data/api_key.txt)
  Map<String, String> get _headers => _apiKey.isEmpty ? const {} : {'X-Api-Key': _apiKey};

  String get directBoardBaseUrl => 'http://$_boardIp:$_boardPort';

  /// ยิงตรงเข้าบอร์ดเฉพาะเมื่อใช้ API แบบ HTTP ในวง LAN เดียวกัน
  /// ถ้าใช้เซิร์ฟเวอร์สาธารณะ (HTTPS) บอร์ดอาจอยู่คนละเครือข่าย (เช่น ฮอตสปอต) จึงข้ามเพื่อไม่ให้เสียเวลารอ timeout
  bool get _useDirectBoard => !_localApiUrl.startsWith('https://');
  String get localApiUrl => _localApiUrl;

  /// Fetches complete telemetry from local backend API or directly from ESP32
  Future<TelemetryModel> fetchTelemetry() async {
    // 1. Try PHP Central API first (rich database + complete sensor telemetry)
    try {
      final uri = Uri.parse('$_localApiUrl?action=get_telemetry');
      final response = await http.get(uri).timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          return TelemetryModel.fromJson(data);
        }
      }
    } catch (_) {}

    // 2. Auto-fallback across LAN candidate URLs
    for (final candidate in ApiConstants.fallbackCandidateUrls) {
      if (candidate == _localApiUrl) continue;
      try {
        final uri = Uri.parse(candidate.contains('?') ? candidate : '$candidate?action=get_telemetry');
        final response = await http.get(uri).timeout(const Duration(milliseconds: 1500));
        if (response.statusCode == 200) {
          final Map<String, dynamic> data = jsonDecode(response.body);
          if (data['status'] == 'success') {
            // ไม่สลับจากเซิร์ฟเวอร์สาธารณะ (HTTPS) ไปเป็น URL วง LAN เพื่อไม่ให้คำสั่งไปผิดเซิร์ฟเวอร์
            if (!candidate.contains('aiot-fleet-dashboard') && !_localApiUrl.startsWith('https://')) {
              _localApiUrl = candidate;
            }
            return TelemetryModel.fromJson(data);
          }
        }
      } catch (_) {}
    }

    // 3. Fallback to localhost (for testing on desktop/emulator)
    try {
      final fallbackUri = Uri.parse('${ApiConstants.fallbackLocalhostUrl}?action=get_telemetry');
      final response = await http.get(fallbackUri).timeout(const Duration(milliseconds: 1500));
      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          return TelemetryModel.fromJson(data);
        }
      }
    } catch (_) {}

    // 4. Direct ESP32 Board fallback query
    try {
      final directUri = Uri.parse('$directBoardBaseUrl/status');
      final response = await http.get(directUri).timeout(const Duration(milliseconds: 1500));
      if (response.statusCode == 200) {
        final Map<String, dynamic> boardStatus = jsonDecode(response.body);
        return TelemetryModel.fromJson({
          'status': 'success',
          'board': {
            'device_name': 'ESP32-S3 ATD3.5 Smart Farm',
            'ip_address': _boardIp,
            'web_port': _boardPort,
            'status': 'CONNECTED (DIRECT BOARD)',
            'is_live': true,
          },
          'sensors': {},
          'relays': {
            '1': {'id': 1, 'state': (boardStatus['relays']?['1'] == 1), 'gpio': 39, 'name': 'ปั๊มน้ำหลัก (Main Pump 1)'},
            '2': {'id': 2, 'state': (boardStatus['relays']?['2'] == 1), 'gpio': 38, 'name': 'วาล์วน้ำโซลินอยด์/ปั๊ม 2'},
            '3': {'id': 3, 'state': (boardStatus['relays']?['3'] == 1), 'gpio': 7, 'name': 'วาล์วน้ำผิวดิน (Surface Valve)'},
            '4': {'id': 4, 'state': (boardStatus['relays']?['4'] == 1), 'gpio': 6, 'name': 'ระบบพ่นหมอกลดอุณหภูมิ'},
          },
          'auto_mode': boardStatus['mode'] == 'AUTO',
          'control_mode': boardStatus['mode']?.toString().toLowerCase() ?? 'manual',
          'ai_calibrated': {},
          'gps': {},
        });
      }
    } catch (_) {}

    throw Exception('ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์หรือบอร์ด ESP32 ได้ กรุณาตรวจสอบ IP หรือเครือข่าย Wi-Fi');
  }

  /// ส่งคำสั่งรีเลย์ผ่านเซิร์ฟเวอร์ (ข้ามเครือข่ายได้) และยิงตรงเข้าบอร์ดเฉพาะเมื่ออยู่วง LAN เดียวกัน
  /// durationMin > 0 = ปิดอัตโนมัติเมื่อครบเวลา (ใช้กับคำสั่งเปิดเท่านั้น)
  Future<CommandResult> controlRelay(int relayId, bool state, {int durationMin = 0}) async {
    final int stateInt = state ? 1 : 0;
    bool directOk = false;

    if (_useDirectBoard) {
      try {
        final directUri = Uri.parse('$directBoardBaseUrl/relay?id=$relayId&state=$stateInt');
        final res = await http.get(directUri).timeout(const Duration(milliseconds: 1200));
        if (res.statusCode == 200) directOk = true;
      } catch (_) {}
    }

    final dur = (state && durationMin > 0) ? '&duration=$durationMin' : '';
    final r = await _call('control_relay&id=$relayId&state=$stateInt$dur&src=app');
    if (!r.ok && directOk) return const CommandResult(true, 'สั่งบอร์ดโดยตรงสำเร็จ แต่เซิร์ฟเวอร์ไม่ตอบ');
    return r;
  }

  /// เปลี่ยนโหมด: 'manual', 'auto' หรือ 'ai'
  Future<CommandResult> setControlMode(String mode) async {
    final cleanMode = mode.toLowerCase();
    bool directOk = false;

    if (_useDirectBoard) {
      try {
        final directUri = Uri.parse('$directBoardBaseUrl/mode?mode=$cleanMode');
        final res = await http.get(directUri).timeout(const Duration(milliseconds: 1200));
        if (res.statusCode == 200) directOk = true;
      } catch (_) {}
    }

    final r = await _call('set_control_mode&mode=$cleanMode&src=app');
    if (!r.ok && directOk) return const CommandResult(true, 'สั่งบอร์ดโดยตรงสำเร็จ แต่เซิร์ฟเวอร์ไม่ตอบ');
    return r;
  }

  /// เรียก endpoint ของเซิร์ฟเวอร์ (query = ส่วนหลัง action=) แล้วตรวจผลลัพธ์
  Future<CommandResult> _call(String query, {Map<String, dynamic>? body}) async {
    try {
      final uri = Uri.parse('$_localApiUrl?action=$query');
      final http.Response res;
      if (body == null) {
        res = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 8));
      } else {
        res = await http
            .post(uri, headers: {..._headers, 'Content-Type': 'application/json'}, body: jsonEncode(body))
            .timeout(const Duration(seconds: 8));
      }
      Map<String, dynamic>? j;
      try {
        j = jsonDecode(res.body) as Map<String, dynamic>;
      } catch (_) {}
      if (res.statusCode == 401) return const CommandResult(false, 'API Key ไม่ถูกต้อง — ตรวจสอบที่หน้าตั้งค่า');
      if (res.statusCode != 200) return CommandResult(false, 'เซิร์ฟเวอร์ตอบ HTTP ${res.statusCode}');
      if (j == null) return const CommandResult(false, 'เซิร์ฟเวอร์ตอบข้อมูลที่อ่านไม่ได้');
      if (j['status'] == 'success') return CommandResult(true, j['message']?.toString() ?? 'สำเร็จ', data: j);
      return CommandResult(false, j['message']?.toString() ?? 'เซิร์ฟเวอร์ปฏิเสธคำสั่ง', data: j);
    } on TimeoutException {
      return const CommandResult(false, 'หมดเวลารอเซิร์ฟเวอร์');
    } catch (_) {
      return const CommandResult(false, 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้');
    }
  }

  // ── ตารางเวลา ─────────────────────────────────────────────
  Future<List<ScheduleItem>> getSchedules() async {
    final r = await _call('get_schedules');
    final list = r.data?['schedules'];
    if (!r.ok || list is! List) throw Exception(r.message);
    return list.whereType<Map>().map((e) => ScheduleItem.fromJson(Map<String, dynamic>.from(e))).toList();
  }

  Future<CommandResult> saveSchedule(Map<String, dynamic> s) {
    final q = StringBuffer('save_schedule');
    s.forEach((k, v) {
      if (v == null) return;
      final val = v is List ? v.join(',') : v.toString();
      q.write('&$k=${Uri.encodeQueryComponent(val)}');
    });
    q.write('&src=app');
    return _call(q.toString());
  }

  Future<CommandResult> deleteSchedule(String id) => _call('delete_schedule&id=${Uri.encodeQueryComponent(id)}&src=app');


  // ── กฎอัตโนมัติ + ค่าชดเชยเซนเซอร์ ─────────────────────────
  Future<RulesState> getRules() async {
    final r = await _call('get_rules');
    if (!r.ok || r.data == null) throw Exception(r.message);
    return RulesState.fromJson(r.data!);
  }

  Future<CommandResult> saveRule(Map<String, dynamic> rule) => _call('save_rule&src=app', body: rule);
  Future<CommandResult> deleteRule(String id) => _call('delete_rule&src=app', body: {'id': id});
  Future<CommandResult> setRulesEnabled(bool on) => _call('set_rules_enabled&src=app', body: {'enabled': on ? 1 : 0});

  Future<CalibrationState> getCalibration() async {
    final r = await _call('get_calibration');
    if (!r.ok || r.data == null) throw Exception(r.message);
    return CalibrationState.fromJson(r.data!);
  }

  Future<CommandResult> saveCalibration(Map<String, Map<String, double>> cal) =>
      _call('save_calibration&src=app', body: {'calibration': cal});

  // ── บันทึกการใช้งาน / แจ้งเตือน / โปรไฟล์ / ประวัติ ──────────
  Future<List<AuditEntry>> getAudit({int limit = 80}) async {
    final r = await _call('get_audit&limit=$limit');
    final list = r.data?['log'];
    if (!r.ok || list is! List) throw Exception(r.message);
    return list.whereType<Map>().map((e) => AuditEntry.fromJson(Map<String, dynamic>.from(e))).toList();
  }

  Future<List<AlertItem>> getAlerts() async {
    final r = await _call('get_alerts');
    final list = r.data?['alerts'];
    if (!r.ok || list is! List) throw Exception(r.message);
    return list.whereType<Map>().map((e) => AlertItem.fromJson(Map<String, dynamic>.from(e))).toList();
  }

  /// คืน (id ที่ใช้งานอยู่, โปรไฟล์ทั้งหมด)
  Future<(String, List<PlantProfile>)> getProfiles() async {
    final r = await _call('get_profiles');
    final raw = r.data?['profiles'];
    if (!r.ok || raw is! Map) throw Exception(r.message);
    final list = raw.values.whereType<Map>().map((e) => PlantProfile.fromJson(Map<String, dynamic>.from(e))).toList();
    return (r.data?['active']?.toString() ?? 'general', list);
  }

  Future<CommandResult> setProfile(String id) => _call('set_profile&id=${Uri.encodeQueryComponent(id)}&src=app');

  Future<HistoryResult> getHistory({int limit = 60}) async {
    final r = await _call('get_history&limit=$limit');
    final list = r.data?['data'];
    if (!r.ok || list is! List) throw Exception(r.message);
    final pts = list.whereType<Map>().map((e) => HistoryPoint.fromJson(Map<String, dynamic>.from(e))).toList();
    return HistoryResult(pts, r.data?['simulated'] == true);
  }

  /// Quick latency test to ESP32 board
  Future<int?> pingBoard() async {
    if (!_useDirectBoard) return null; // ใช้เซิร์ฟเวอร์สาธารณะ: ไม่ยิงเข้า IP ของบอร์ดตรงๆ
    final stopwatch = Stopwatch()..start();
    try {
      final uri = Uri.parse('$directBoardBaseUrl/status');
      final res = await http.get(uri).timeout(const Duration(milliseconds: 1500));
      stopwatch.stop();
      if (res.statusCode == 200) {
        return stopwatch.elapsedMilliseconds;
      }
    } catch (_) {}
    return null;
  }
}
