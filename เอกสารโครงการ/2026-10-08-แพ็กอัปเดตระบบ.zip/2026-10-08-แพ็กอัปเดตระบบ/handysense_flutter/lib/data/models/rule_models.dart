/// โมเดลของกฎอัตโนมัติและค่าชดเชยเซนเซอร์ (ตรงกับ api/rules.php)

/// เซนเซอร์ที่ใช้เป็นเงื่อนไขได้: key → (ชื่อไทย, หน่วย)
const Map<String, (String, String)> ruleSensors = {
  'soil_moisture': ('ความชื้นดิน', '%'),
  'temperature': ('อุณหภูมิอากาศ', '°C'),
  'humidity': ('ความชื้นอากาศ', '%'),
  'vpd': ('VPD', 'kPa'),
  'soil_ph': ('pH ดิน', ''),
  'soil_ec': ('EC ดิน', 'µS/cm'),
  'soil_temperature': ('อุณหภูมิดิน', '°C'),
};

/// เซนเซอร์ที่ชดเชยค่าได้
const List<String> calibrationSensors = [
  'temperature',
  'humidity',
  'soil_moisture',
  'soil_ph',
  'soil_ec',
  'soil_temperature',
];

class RuleCondition {
  final String sensor;
  final String op; // < <= > >=
  final double value;
  const RuleCondition({required this.sensor, required this.op, required this.value});

  factory RuleCondition.fromJson(Map<String, dynamic> j) => RuleCondition(
        sensor: j['sensor']?.toString() ?? 'soil_moisture',
        op: j['op']?.toString() ?? '<',
        value: (j['value'] as num?)?.toDouble() ?? 0,
      );

  Map<String, dynamic> toJson() => {'sensor': sensor, 'op': op, 'value': value};

  String get text {
    final s = ruleSensors[sensor];
    return '${s?.$1 ?? sensor} $op ${_fmt(value)}${(s?.$2 ?? '').isEmpty ? '' : ' ${s!.$2}'}';
  }
}

String _fmt(double v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toString();

class RuleItem {
  final String id;
  final String name;
  final bool enabled;
  final int relay;
  final bool turnOn;
  final bool matchAny; // true = หรือ, false = และ
  final List<RuleCondition> conditions;
  final RuleCondition? stop;
  final int durationMin;
  final int holdSec;
  final int cooldownMin;
  final String? windowStart;
  final String? windowEnd;
  final List<int> days;
  final bool running; // กฎนี้เป็นผู้สั่งเปิดอยู่
  final int lastFire; // epoch วินาที (0 = ยังไม่เคย)

  const RuleItem({
    required this.id,
    required this.name,
    required this.enabled,
    required this.relay,
    required this.turnOn,
    required this.matchAny,
    required this.conditions,
    this.stop,
    required this.durationMin,
    required this.holdSec,
    required this.cooldownMin,
    this.windowStart,
    this.windowEnd,
    required this.days,
    this.running = false,
    this.lastFire = 0,
  });

  factory RuleItem.fromJson(Map<String, dynamic> j, {Map<String, dynamic>? runtime}) {
    final win = j['window'];
    return RuleItem(
      id: j['id']?.toString() ?? '',
      name: j['name']?.toString() ?? '',
      enabled: j['enabled'] == 1 || j['enabled'] == true,
      relay: (j['relay'] as num?)?.toInt() ?? 1,
      turnOn: (j['action']?.toString() ?? 'on') == 'on',
      matchAny: j['logic'] == 'any',
      conditions: ((j['conditions'] as List?) ?? [])
          .whereType<Map>()
          .map((e) => RuleCondition.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
      stop: j['stop'] is Map ? RuleCondition.fromJson(Map<String, dynamic>.from(j['stop'] as Map)) : null,
      durationMin: (j['duration'] as num?)?.toInt() ?? 0,
      holdSec: (j['hold_sec'] as num?)?.toInt() ?? 0,
      cooldownMin: (j['cooldown_min'] as num?)?.toInt() ?? 0,
      windowStart: win is Map ? win['start']?.toString() : null,
      windowEnd: win is Map ? win['end']?.toString() : null,
      days: ((j['days'] as List?) ?? [0, 1, 2, 3, 4, 5, 6]).map((e) => (e as num).toInt()).toList(),
      running: runtime?['on_by'] == true,
      lastFire: (runtime?['last_fire'] as num?)?.toInt() ?? 0,
    );
  }

  Map<String, dynamic> toJson({bool? enabledOverride}) => {
        'id': id,
        'name': name,
        'enabled': (enabledOverride ?? enabled) ? 1 : 0,
        'relay': relay,
        'action': turnOn ? 'on' : 'off',
        'logic': matchAny ? 'any' : 'all',
        'conditions': conditions.map((c) => c.toJson()).toList(),
        if (stop != null) 'stop': stop!.toJson(),
        'duration': durationMin,
        'hold_sec': holdSec,
        'cooldown_min': cooldownMin,
        if (windowStart != null && windowEnd != null) 'window': {'start': windowStart, 'end': windowEnd},
        'days': days,
      };
}

class RulesState {
  final bool enabled;
  final List<RuleItem> rules;
  const RulesState({required this.enabled, required this.rules});

  factory RulesState.fromJson(Map<String, dynamic> j) {
    final rt = j['runtime'] is Map ? Map<String, dynamic>.from(j['runtime'] as Map) : <String, dynamic>{};
    return RulesState(
      enabled: j['enabled'] == true || j['enabled'] == 1,
      rules: ((j['rules'] as List?) ?? []).whereType<Map>().map((e) {
        final m = Map<String, dynamic>.from(e);
        final r = rt[m['id']?.toString() ?? ''];
        return RuleItem.fromJson(m, runtime: r is Map ? Map<String, dynamic>.from(r) : null);
      }).toList(),
    );
  }
}

class CalibrationEntry {
  final double offset;
  final double gain;
  const CalibrationEntry({this.offset = 0, this.gain = 1});
  bool get isDefault => offset.abs() < 1e-9 && (gain - 1).abs() < 1e-9;
}

class CalibrationState {
  final Map<String, CalibrationEntry> cal;
  final Map<String, double> raw;
  final bool active;
  const CalibrationState({required this.cal, required this.raw, required this.active});

  factory CalibrationState.fromJson(Map<String, dynamic> j) {
    final c = j['calibration'] is Map ? Map<String, dynamic>.from(j['calibration'] as Map) : <String, dynamic>{};
    final r = j['raw'] is Map ? Map<String, dynamic>.from(j['raw'] as Map) : <String, dynamic>{};
    return CalibrationState(
      cal: {
        for (final k in calibrationSensors)
          k: CalibrationEntry(
            offset: ((c[k] as Map?)?['offset'] as num?)?.toDouble() ?? 0,
            gain: ((c[k] as Map?)?['gain'] as num?)?.toDouble() ?? 1,
          ),
      },
      raw: {
        for (final e in r.entries)
          if (e.value is num) e.key: (e.value as num).toDouble(),
      },
      active: j['active'] == true,
    );
  }
}
