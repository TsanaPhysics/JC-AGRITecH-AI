<?php
/**
 * แกนแบบทดสอบ Pre/Post (32 ข้อ) ใช้ร่วมกันโดย pages/assessment_pre.php และ assessment_post.php
 * ตัวแปรที่ต้องตั้งก่อน include:  $QUIZ_MODE = 'pre' | 'post'
 * ธนาคารข้อสอบ: includes/quiz_bank.json  (แก้ข้อสอบที่ไฟล์นี้ไฟล์เดียว)
 * หมายเหตุ: เฉลยอยู่ในหน้าเว็บ (ฝั่งผู้ใช้) เหมาะกับการฝึกอบรม ไม่ใช่การสอบที่ต้องป้องกันการโกง
 */
$QUIZ_MODE = (isset($QUIZ_MODE) && $QUIZ_MODE === 'post') ? 'post' : 'pre';
$__bank = json_decode((string)@file_get_contents(__DIR__ . '/quiz_bank.json'), true);
if (!is_array($__bank)) { $__bank = []; }
$__order = range(0, count($__bank) - 1);
if ($QUIZ_MODE === 'post') { shuffle($__order); }   // ข้อสอบหลังเรียนสลับลำดับ
$__letters = ['ก', 'ข', 'ค', 'ง'];
?>
<form id="quizForm" class="space-y-6 text-sm" autocomplete="off">
  <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
    <div class="sm:col-span-2">
      <label class="block text-xs font-semibold text-slate-300 mb-1">ชื่อ-นามสกุล / รหัสผู้เข้าร่วม <span class="text-rose-400">*</span></label>
      <input id="qzName" required maxlength="80" class="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-sm focus:border-cyan-400 outline-none" placeholder="ใช้ชื่อเดียวกันทั้งก่อนและหลังเรียน">
    </div>
    <div>
      <label class="block text-xs font-semibold text-slate-300 mb-1">กลุ่มที่</label>
      <select id="qzGroup" class="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-sm outline-none">
        <option value="">-</option><?php for ($g = 1; $g <= 10; $g++) echo "<option>$g</option>"; ?>
      </select>
    </div>
  </div>
  <div class="sticky top-16 z-10 py-2 px-3 rounded-xl bg-slate-900/95 border border-slate-800 text-xs text-slate-300 flex justify-between">
    <span>ตอบแล้ว <b id="qzDone" class="text-cyan-300">0</b>/<?php echo count($__bank); ?> ข้อ</span>
    <span class="text-slate-500">ข้อสอบ <?php echo count($__bank); ?> ข้อ ใช้เวลาประมาณ 30 นาที</span>
  </div>
<?php foreach ($__order as $n => $i): $q = $__bank[$i]; ?>
  <div class="p-4 sm:p-5 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-3" data-qi="<?php echo $i; ?>">
    <div class="font-bold text-white flex items-start gap-2">
      <span class="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-mono text-xs shrink-0">ข้อ <?php echo $n + 1; ?></span>
      <span><?php echo htmlspecialchars($q['q'], ENT_QUOTES, 'UTF-8'); ?></span>
    </div>
    <div class="space-y-2 text-xs sm:text-sm text-slate-300 pl-2 sm:pl-8">
<?php $__ks = array_keys($q['o']); shuffle($__ks); foreach ($__ks as $pos => $k): $opt = $q['o'][$k]; ?>
      <label class="flex items-start gap-2.5 cursor-pointer hover:text-white">
        <input type="radio" name="q<?php echo $i; ?>" value="<?php echo $k; ?>" class="accent-cyan-400 mt-1">
        <span><?php echo $__letters[$pos] . '. ' . htmlspecialchars($opt, ENT_QUOTES, 'UTF-8'); ?></span>
      </label>
<?php endforeach; ?>
    </div>
  </div>
<?php endforeach; ?>
  <button type="submit" class="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-sm shadow-xl hover:scale-[1.01] transition">
    <i class="fa-solid fa-check-double"></i> ส่งคำตอบและตรวจผลคะแนน
  </button>
</form>
<div id="quizResult" class="hidden mt-6 p-5 rounded-2xl bg-slate-950 border border-emerald-500/30 space-y-3"></div>

<script>
(function () {
  const BANK = <?php echo json_encode($__bank, JSON_UNESCAPED_UNICODE); ?>;
  const MODE = <?php echo json_encode($QUIZ_MODE); ?>;
  const L = ['ก', 'ข', 'ค', 'ง'];
  const form = document.getElementById('quizForm');
  const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  window.QUIZ_DONE = false; window.QUIZ_NAME = '';
  function count() { document.getElementById('qzDone').textContent = form.querySelectorAll('input[type=radio]:checked').length; }
  form.addEventListener('change', count);
  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    const answered = form.querySelectorAll('input[type=radio]:checked').length;
    if (answered < BANK.length && !confirm('ยังตอบไม่ครบ (' + answered + '/' + BANK.length + ') ส่งคำตอบเลยหรือไม่?')) return;
    let score = 0; const topics = {}; const ans = {}; const wrong = [];
    BANK.forEach((q, i) => {
      const sel = form.querySelector('input[name="q' + i + '"]:checked');
      const v = sel ? parseInt(sel.value, 10) : -1; ans[i] = v;
      topics[q.t] = topics[q.t] || [0, 0]; topics[q.t][1]++;
      if (v === q.a) { score++; topics[q.t][0]++; } else wrong.push(i);
    });
    const pct = Math.round(score * 100 / BANK.length);
    const name = document.getElementById('qzName').value.trim();
    let html = '<div class="text-center"><div class="text-3xl font-black text-white">' + score + '/' + BANK.length + ' <span class="text-lg text-emerald-400">(' + pct + '%)</span></div><div class="text-xs text-slate-400">' + (MODE === 'pre' ? 'คะแนนก่อนเรียน' : 'คะแนนหลังเรียน') + '</div></div>';
    html += '<div class="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">' + Object.keys(topics).map(t => '<div class="p-2 rounded-xl bg-slate-900 border border-slate-800"><div class="text-slate-400">' + esc(t) + '</div><b class="text-cyan-300">' + topics[t][0] + '/' + topics[t][1] + '</b></div>').join('') + '</div>';
    if (wrong.length) {
      html += '<details class="text-xs text-slate-300"><summary class="cursor-pointer text-amber-300 font-bold">ข้อที่ตอบผิดหรือยังไม่ได้ตอบ (' + wrong.length + ') — ดูเฉลย</summary><div class="space-y-3 mt-2">' +
        wrong.map(i => '<div class="p-2 rounded-xl bg-slate-900"><div class="font-bold text-white">' + esc(BANK[i].q) + '</div><div class="text-emerald-300">เฉลย: ' + esc(BANK[i].o[BANK[i].a]) + '</div><div class="text-slate-400">' + esc(BANK[i].e || '') + '</div></div>').join('') + '</div></details>';
    }
    html += '<div id="quizSaveMsg" class="text-xs text-slate-400">กำลังบันทึกผล…</div>';
    const box = document.getElementById('quizResult'); box.innerHTML = html; box.classList.remove('hidden'); box.scrollIntoView({behavior: 'smooth'});
    window.QUIZ_DONE = true; window.QUIZ_NAME = name; window.QUIZ_SCORE = score;
    document.dispatchEvent(new CustomEvent('quizdone', {detail: {name, score, total: BANK.length}}));
    form.querySelectorAll('input,select,button').forEach(el => el.disabled = true);
    try {
      const r = await fetch('quiz_save.php', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({mode: MODE, name, group: document.getElementById('qzGroup').value, score, total: BANK.length, topics})});
      const j = await r.json();
      document.getElementById('quizSaveMsg').textContent = j.status === 'success' ? 'บันทึกผลเข้าระบบแล้ว' : ('บันทึกผลไม่สำเร็จ: ' + (j.message || ''));
    } catch (err) { document.getElementById('quizSaveMsg').textContent = 'บันทึกผลเข้าระบบไม่ได้ (ผลด้านบนยังใช้ได้)'; }
  });
})();
</script>
