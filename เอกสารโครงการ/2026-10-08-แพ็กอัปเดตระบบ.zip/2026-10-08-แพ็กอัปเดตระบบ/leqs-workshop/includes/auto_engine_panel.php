<?php
/**
 * แผงโหมดอัตโนมัติ (กฎตามเงื่อนไข + ตารางเวลา + ค่าชดเชยเซนเซอร์) ใช้ร่วมกันทั้งแดชบอร์ดและมือถือ
 * ตัวแปรที่รับ: $AE_SRC = 'web' | 'mobile'  (ไม่ตั้ง = web)
 * ใช้ API: get_rules/save_rule/delete_rule/set_rules_enabled, get_schedules/save_schedule/delete_schedule,
 *         get_calibration/save_calibration, get_telemetry  (ดู api/rules.php)
 */
$AE_SRC = isset($AE_SRC) ? $AE_SRC : 'web';
$__aekf = __DIR__ . '/../data/api_key.txt';
$__aek = is_file($__aekf) ? trim((string)@file_get_contents($__aekf)) : '';
?>
<section id="aePanel" class="ae-panel rounded-3xl border border-slate-800/80 bg-slate-900/60 p-4 sm:p-6 space-y-5 text-slate-100">
<style>
#aePanel{font-size:14px;color:#e2e8f0}
#aePanel h3{font-weight:700;font-size:15px;color:#fff}
#aePanel .ae-card{background:#0f172a;border:1px solid #1e293b;border-radius:16px;padding:12px}
#aePanel label{display:block;font-size:11px;color:#94a3b8;margin-bottom:2px}
#aePanel input,#aePanel select{width:100%;background:#020617;border:1px solid #334155;border-radius:10px;padding:7px 9px;color:#fff;font-size:13px;min-height:36px}
#aePanel input[type=checkbox]{width:auto;min-height:0}
#aePanel .ae-btn{border-radius:10px;padding:7px 12px;font-weight:700;font-size:12px;border:0;cursor:pointer;background:#0891b2;color:#fff;min-height:34px}
#aePanel .ae-btn.ghost{background:transparent;border:1px solid #334155;color:#cbd5e1}
#aePanel .ae-btn.red{background:#be123c}
#aePanel .ae-btn.green{background:#059669}
#aePanel .ae-row{display:grid;gap:8px}
#aePanel .ae-g2{grid-template-columns:1fr 1fr}
#aePanel .ae-g3{grid-template-columns:1fr 1fr 1fr}
#aePanel .ae-cond{display:grid;grid-template-columns:1.6fr .7fr 1fr auto;gap:6px;margin-bottom:6px}
#aePanel .ae-tag{display:inline-block;font-size:10px;padding:1px 7px;border-radius:999px;background:#1e293b;color:#94a3b8}
#aePanel .ae-tag.on{background:#064e3b;color:#6ee7b7}
#aePanel .ae-tag.warn{background:#78350f;color:#fcd34d}
#aePanel .ae-muted{color:#94a3b8;font-size:12px}
#aePanel .ae-sw{position:relative;width:46px;height:26px;background:#334155;border-radius:999px;cursor:pointer;flex:none;border:0;padding:0}
#aePanel .ae-sw::after{content:"";position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#fff;transition:.15s}
#aePanel .ae-sw.on{background:#10b981}
#aePanel .ae-sw.on::after{left:23px}
#aePanel .ae-days label{display:inline-flex;align-items:center;gap:3px;margin-right:6px;font-size:12px;color:#e2e8f0}
@media(max-width:480px){#aePanel .ae-g3{grid-template-columns:1fr 1fr}#aePanel .ae-cond{grid-template-columns:1fr 1fr}}
</style>

<div class="flex items-center justify-between gap-3">
  <div>
    <h3><i class="fa-solid fa-robot text-emerald-400"></i> โหมดอัตโนมัติ (กฎตามเงื่อนไข)</h3>
    <p class="ae-muted">สั่งรีเลย์อัตโนมัติจากค่าเซนเซอร์ ช่วงเวลา และวัน ทำงานเมื่อบอร์ดออนไลน์เท่านั้น</p>
  </div>
  <button id="aeMaster" class="ae-sw" aria-label="เปิด/ปิดระบบกฎอัตโนมัติ"></button>
</div>
<div id="aeMsg" class="ae-muted" role="status"></div>

<div>
  <div class="flex items-center justify-between mb-2"><h3>กฎที่ตั้งไว้ <span id="aeRuleCount" class="ae-muted"></span></h3>
    <button class="ae-btn" onclick="AE.newRule()">+ เพิ่มกฎ</button></div>
  <div id="aeRules" class="space-y-2"></div>
</div>

<div id="aeForm" class="ae-card hidden" style="display:none">
  <h3 id="aeFormTitle">เพิ่มกฎ</h3>
  <div class="ae-muted" style="margin:4px 0 8px">ตัวอย่างสำเร็จรูป:
    <a href="#" onclick="AE.preset('soil');return false" class="text-cyan-400">ดินแห้งแล้วรดน้ำ</a> ·
    <a href="#" onclick="AE.preset('vpd');return false" class="text-cyan-400">VPD สูงแล้วพ่นหมอก</a> ·
    <a href="#" onclick="AE.preset('hot');return false" class="text-cyan-400">ร้อนแล้วพ่นหมอก (เฉพาะกลางวัน)</a></div>
  <div class="ae-row ae-g2">
    <div><label>ชื่อกฎ</label><input id="aeName" maxlength="60" placeholder="เช่น รดน้ำเมื่อดินแห้ง"></div>
    <div><label>รีเลย์ที่สั่ง</label><select id="aeRelay"></select></div>
    <div><label>การกระทำ</label><select id="aeAction"><option value="on">เปิด</option><option value="off">ปิด</option></select></div>
    <div><label>เมื่อเงื่อนไข</label><select id="aeLogic"><option value="all">เป็นจริงทุกข้อ (และ)</option><option value="any">เป็นจริงอย่างน้อย 1 ข้อ (หรือ)</option></select></div>
  </div>
  <label style="margin-top:10px">เงื่อนไข (สูงสุด 4 ข้อ)</label>
  <div id="aeConds"></div>
  <button class="ae-btn ghost" onclick="AE.addCond()">+ เพิ่มเงื่อนไข</button>
  <div class="ae-row ae-g3" style="margin-top:10px">
    <div><label>เปิดนาน (นาที, 0 = ไม่จำกัด)</label><input id="aeDur" type="number" min="0" max="720" value="5"></div>
    <div><label>ต้องคงเงื่อนไขนาน (วินาที)</label><input id="aeHold" type="number" min="0" max="3600" value="30"></div>
    <div><label>พักก่อนสั่งซ้ำ (นาที)</label><input id="aeCool" type="number" min="0" max="720" value="10"></div>
  </div>
  <div class="ae-muted" style="margin-top:4px">ค่า "คงเงื่อนไขนาน" ช่วยกรองสัญญาณรบกวน ส่วน "พักก่อนสั่งซ้ำ" ป้องกันรีเลย์ติด-ดับถี่</div>
  <label style="margin-top:10px"><input type="checkbox" id="aeStopOn"> หยุดอัตโนมัติเมื่อถึงเงื่อนไข (ใช้กับการสั่งเปิด)</label>
  <div id="aeStopRow" class="ae-cond" style="display:none;grid-template-columns:1.6fr .7fr 1fr"></div>
  <div class="ae-row ae-g2" style="margin-top:10px">
    <div><label>ทำงานเฉพาะช่วงเวลา: เริ่ม (ว่าง = ตลอดวัน)</label><input id="aeWinS" type="time"></div>
    <div><label>สิ้นสุด</label><input id="aeWinE" type="time"></div>
  </div>
  <div class="ae-days" id="aeDays" style="margin-top:10px"></div>
  <div class="flex gap-2" style="margin-top:12px">
    <button class="ae-btn green" onclick="AE.saveRule()">บันทึกกฎ</button>
    <button class="ae-btn ghost" onclick="AE.closeForm()">ยกเลิก</button>
  </div>
</div>

<div>
  <div class="flex items-center justify-between mb-2"><h3>ตารางเวลา (ตามนาฬิกา)</h3>
    <button class="ae-btn" onclick="AE.toggleSchForm()">+ เพิ่มเวลา</button></div>
  <div id="aeSchForm" class="ae-card" style="display:none;margin-bottom:8px">
    <div class="ae-row ae-g3">
      <div><label>เวลา</label><input id="aeSchTime" type="time" value="06:00"></div>
      <div><label>รีเลย์</label><select id="aeSchRelay"></select></div>
      <div><label>การกระทำ</label><select id="aeSchAct"><option value="on">เปิด</option><option value="off">ปิด</option></select></div>
      <div><label>เปิดนาน (นาที, 0 = ไม่จำกัด)</label><input id="aeSchDur" type="number" min="0" max="720" value="10"></div>
      <div style="grid-column:span 2"><label>ชื่อ (ไม่บังคับ)</label><input id="aeSchName" maxlength="60"></div>
    </div>
    <div class="ae-days" id="aeSchDays" style="margin-top:8px"></div>
    <div class="flex gap-2" style="margin-top:10px"><button class="ae-btn green" onclick="AE.saveSch()">บันทึก</button><button class="ae-btn ghost" onclick="AE.toggleSchForm()">ยกเลิก</button></div>
  </div>
  <div id="aeSchList" class="space-y-2"></div>
</div>

<div>
  <div class="flex items-center justify-between mb-2"><h3>ชดเชยความคลาดเคลื่อนเซนเซอร์ <span id="aeCalTag" class="ae-tag"></span></h3></div>
  <p class="ae-muted" style="margin-bottom:6px">ค่าที่ใช้ = ค่าดิบ × อัตราส่วน + ค่าชดเชย ใช้กับการแสดงผล กฎอัตโนมัติ การแจ้งเตือน และบันทึกประวัติ VPD และจุดน้ำค้างคำนวณใหม่จากอุณหภูมิ/ความชื้นที่ชดเชยแล้ว
  วิธีหาค่า: วัดด้วยเครื่องมืออ้างอิง (เช่น เทอร์โมมิเตอร์/ความชื้นมาตรฐาน หรือชั่งดินหาความชื้นจริง) แล้วกรอกในช่อง "ค่าอ้างอิง" กด "คำนวณ" ระบบจะตั้งค่าชดเชยให้ ณ จุดนั้น</p>
  <div id="aeCal" class="space-y-2"></div>
  <div class="flex gap-2" style="margin-top:10px"><button class="ae-btn green" onclick="AE.saveCal()">บันทึกค่าชดเชย</button><button class="ae-btn ghost" onclick="AE.resetCal()">คืนค่าเริ่มต้น</button></div>
</div>

<script>
(function(){
  const BASE = '../api/api.php', SRC = <?php echo json_encode($AE_SRC); ?>;
  const KEY = <?php echo json_encode($__aek !== '' ? '&key=' . rawurlencode($__aek) : ''); ?>;
  const DAYS = ['อา','จ','อ','พ','พฤ','ศ','ส'];
  const SENS = {soil_moisture:['ความชื้นดิน','%'],temperature:['อุณหภูมิอากาศ','°C'],humidity:['ความชื้นอากาศ','%'],vpd:['VPD','kPa'],soil_ph:['pH ดิน',''],soil_ec:['EC ดิน','µS/cm'],soil_temperature:['อุณหภูมิดิน','°C']};
  const CALS = ['temperature','humidity','soil_moisture','soil_ph','soil_ec','soil_temperature'];
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let S = {rules:[], enabled:false, relays:{}, sch:[], cal:{}, raw:{}, rt:{}, editId:null, conds:[]};

  async function api(action, params, body){
    let url = BASE + '?action=' + action + '&src=' + SRC + KEY;
    if (params) for (const k in params) url += '&' + k + '=' + encodeURIComponent(params[k]);
    const opt = body ? {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)} : {cache:'no-store'};
    const r = await fetch(url, opt); return r.json();
  }
  function msg(t, bad){ const m=$('aeMsg'); m.textContent=t||''; m.style.color = bad ? '#fda4af' : '#94a3b8'; if(t) setTimeout(()=>{ if(m.textContent===t) m.textContent=''; }, 5000); }
  function condText(c){ const s=SENS[c.sensor]||[c.sensor,'']; return s[0]+' '+c.op+' '+c.value+(s[1]?' '+s[1]:''); }
  function relayName(r){ return (S.relays[r] && S.relays[r].name) ? S.relays[r].name : 'รีเลย์ '+r; }
  function sensorOpts(sel){ return Object.keys(SENS).map(k=>'<option value="'+k+'"'+(k===sel?' selected':'')+'>'+SENS[k][0]+'</option>').join(''); }
  function opOpts(sel){ return ['<','<=','>','>='].map(o=>'<option'+(o===sel?' selected':'')+'>'+esc(o)+'</option>').join(''); }

  function renderRules(){
    $('aeMaster').classList.toggle('on', !!S.enabled);
    $('aeRuleCount').textContent = '(' + S.rules.length + ')';
    $('aeRules').innerHTML = S.rules.length ? S.rules.map(r=>{
      const rt = S.rt[r.id] || {};
      const cond = r.conditions.map(condText).join(r.logic==='any' ? ' หรือ ' : ' และ ');
      const extra = [];
      if (r.action==='on' && r.duration>0) extra.push('เปิด '+r.duration+' นาที');
      if (r.stop) extra.push('หยุดเมื่อ '+condText(r.stop));
      if (r.window) extra.push('เวลา '+r.window.start+'–'+r.window.end);
      if (r.days && r.days.length<7) extra.push('วัน '+r.days.map(d=>DAYS[d]).join(','));
      extra.push('คงเงื่อนไข '+r.hold_sec+' วิ');
      extra.push('พัก '+r.cooldown_min+' นาที');
      const last = rt.last_fire ? new Date(rt.last_fire*1000).toLocaleString('th-TH',{hour:'2-digit',minute:'2-digit',day:'numeric',month:'short'}) : null;
      return '<div class="ae-card"><div class="flex justify-between gap-2"><div style="min-width:0"><b>'+esc(r.name||r.id)+'</b> <span class="ae-tag '+(r.enabled?'on':'')+'">'+(r.enabled?'เปิดใช้':'ปิดอยู่')+'</span>'
        +'<div class="ae-muted">ถ้า '+esc(cond)+' → '+(r.action==='on'?'เปิด ':'ปิด ')+esc(relayName(String(r.relay)))+'</div>'
        +'<div class="ae-muted">'+esc(extra.join(' · '))+(last?' · สั่งล่าสุด '+esc(last):'')+(rt.on_by?' · <span style="color:#6ee7b7">กำลังทำงาน</span>':'')+'</div></div>'
        +'<div class="flex flex-col gap-1" style="flex:none"><button class="ae-btn ghost" onclick="AE.toggleRule(\''+r.id+'\')">'+(r.enabled?'ปิดกฎ':'เปิดกฎ')+'</button><button class="ae-btn ghost" onclick="AE.editRule(\''+r.id+'\')">แก้ไข</button><button class="ae-btn red" onclick="AE.delRule(\''+r.id+'\')">ลบ</button></div></div></div>';
    }).join('') : '<div class="ae-muted">ยังไม่มีกฎ กด "+ เพิ่มกฎ" หรือเลือกตัวอย่างสำเร็จรูป</div>';
    if (S.enabled === false && S.rules.some(r=>r.enabled)) $('aeRules').insertAdjacentHTML('afterbegin','<div class="ae-tag warn" style="margin-bottom:6px">สวิตช์รวมปิดอยู่ กฎจะยังไม่ทำงาน</div>');
  }
  function relayOpts(sel){ return [1,2,3,4].map(i=>'<option value="'+i+'"'+(String(sel)===String(i)?' selected':'')+'>'+i+' · '+esc(relayName(String(i)))+'</option>').join(''); }
  function dayBoxes(id, days){ $(id).innerHTML = DAYS.map((d,i)=>'<label><input type="checkbox" value="'+i+'"'+((days||[0,1,2,3,4,5,6]).includes(i)?' checked':'')+'>'+d+'</label>').join(''); }
  function getDays(id){ return Array.from($(id).querySelectorAll('input:checked')).map(x=>+x.value); }

  function renderConds(){
    $('aeConds').innerHTML = S.conds.map((c,i)=>'<div class="ae-cond"><select data-i="'+i+'" data-f="sensor">'+sensorOpts(c.sensor)+'</select><select data-i="'+i+'" data-f="op">'+opOpts(c.op)+'</select><input data-i="'+i+'" data-f="value" type="number" step="any" value="'+esc(c.value)+'"><button class="ae-btn ghost" onclick="AE.rmCond('+i+')" aria-label="ลบเงื่อนไข">✕</button></div>').join('');
    $('aeConds').querySelectorAll('[data-f]').forEach(el=>el.onchange=el.oninput=()=>{ S.conds[+el.dataset.i][el.dataset.f]=el.value; });
  }
  function renderStop(c){
    const row=$('aeStopRow');
    row.innerHTML='<select id="aeStopS">'+sensorOpts(c.sensor)+'</select><select id="aeStopO">'+opOpts(c.op)+'</select><input id="aeStopV" type="number" step="any" value="'+esc(c.value)+'">';
  }
  function openForm(){ $('aeForm').style.display='block'; $('aeForm').classList.remove('hidden'); $('aeForm').scrollIntoView({behavior:'smooth',block:'nearest'}); }

  function fill(r){
    S.editId = r.id || null;
    $('aeFormTitle').textContent = r.id ? 'แก้ไขกฎ' : 'เพิ่มกฎ';
    $('aeName').value = r.name||''; $('aeRelay').innerHTML = relayOpts(r.relay||1); $('aeAction').value = r.action||'on'; $('aeLogic').value = r.logic||'all';
    S.conds = (r.conditions&&r.conditions.length ? r.conditions : [{sensor:'soil_moisture',op:'<',value:40}]).map(c=>({...c}));
    renderConds();
    $('aeDur').value = r.duration!=null ? r.duration : 5; $('aeHold').value = r.hold_sec!=null ? r.hold_sec : 30; $('aeCool').value = r.cooldown_min!=null ? r.cooldown_min : 10;
    $('aeStopOn').checked = !!r.stop; $('aeStopRow').style.display = r.stop ? 'grid' : 'none';
    renderStop(r.stop || {sensor:'soil_moisture',op:'>=',value:55});
    $('aeWinS').value = r.window ? r.window.start : ''; $('aeWinE').value = r.window ? r.window.end : '';
    dayBoxes('aeDays', r.days);
    openForm();
  }
  const PRESETS = {
    soil:{name:'รดน้ำเมื่อดินแห้ง',relay:1,action:'on',logic:'all',conditions:[{sensor:'soil_moisture',op:'<',value:40}],duration:10,stop:{sensor:'soil_moisture',op:'>=',value:60},hold_sec:60,cooldown_min:30},
    vpd:{name:'พ่นหมอกเมื่อ VPD สูง',relay:4,action:'on',logic:'all',conditions:[{sensor:'vpd',op:'>',value:1.6}],duration:3,stop:{sensor:'vpd',op:'<=',value:1.2},hold_sec:60,cooldown_min:15},
    hot:{name:'ร้อนและแห้ง พ่นหมอก (06:00–18:00)',relay:4,action:'on',logic:'all',conditions:[{sensor:'temperature',op:'>',value:35},{sensor:'humidity',op:'<',value:55}],duration:5,hold_sec:60,cooldown_min:20,window:{start:'06:00',end:'18:00'}}
  };

  window.AE = {
    newRule(){ fill({}); },
    preset(k){ fill({...PRESETS[k]}); },
    editRule(id){ const r=S.rules.find(x=>x.id===id); if(r) fill(r); },
    closeForm(){ $('aeForm').style.display='none'; },
    addCond(){ if(S.conds.length>=4) return; S.conds.push({sensor:'temperature',op:'>',value:35}); renderConds(); },
    rmCond(i){ if(S.conds.length<=1) return; S.conds.splice(i,1); renderConds(); },
    async saveRule(){
      const body = {id:S.editId||'', name:$('aeName').value, relay:+$('aeRelay').value, action:$('aeAction').value, logic:$('aeLogic').value,
        conditions:S.conds.map(c=>({sensor:c.sensor,op:c.op,value:parseFloat(c.value)})), duration:+$('aeDur').value, hold_sec:+$('aeHold').value, cooldown_min:+$('aeCool').value,
        days:getDays('aeDays'), enabled:(S.rules.find(r=>r.id===S.editId)||{enabled:1}).enabled};
      if (S.conds.some(c=>isNaN(parseFloat(c.value)))) { msg('กรอกค่าเงื่อนไขให้ครบ', true); return; }
      if ($('aeStopOn').checked) body.stop = {sensor:$('aeStopS').value, op:$('aeStopO').value, value:parseFloat($('aeStopV').value)};
      if ($('aeWinS').value && $('aeWinE').value) body.window = {start:$('aeWinS').value, end:$('aeWinE').value};
      const r = await api('save_rule', null, body);
      if (r.status==='success'){ S.rules=r.rules; S.enabled=r.enabled; this.closeForm(); renderRules(); msg('บันทึกกฎแล้ว'); } else msg(r.message||'บันทึกไม่สำเร็จ', true);
    },
    async toggleRule(id){ const r=S.rules.find(x=>x.id===id); if(!r) return; const res=await api('save_rule',null,{...r, enabled: r.enabled?0:1}); if(res.status==='success'){S.rules=res.rules;renderRules();} else msg(res.message,true); },
    async delRule(id){ if(!confirm('ลบกฎนี้?')) return; const r=await api('delete_rule',null,{id}); if(r.status==='success'){S.rules=r.rules;renderRules();} else msg(r.message,true); },
    async master(){ const v=!S.enabled; const r=await api('set_rules_enabled',null,{enabled:v?1:0}); if(r.status==='success'){S.enabled=r.enabled;renderRules();msg(r.enabled?'เปิดระบบกฎอัตโนมัติแล้ว':'ปิดระบบกฎอัตโนมัติแล้ว');} else msg(r.message||'ไม่สำเร็จ',true); },
    // schedules
    toggleSchForm(){ const f=$('aeSchForm'); f.style.display = f.style.display==='none'?'block':'none'; $('aeSchRelay').innerHTML=relayOpts(1); dayBoxes('aeSchDays'); },
    async saveSch(){
      const r=await api('save_schedule',null,{time:$('aeSchTime').value,relay:+$('aeSchRelay').value,action_type:$('aeSchAct').value,duration:+$('aeSchDur').value,days:getDays('aeSchDays'),name:$('aeSchName').value,enabled:1});
      if(r.status==='success'){ S.sch=r.schedules; renderSch(); this.toggleSchForm(); msg('บันทึกตารางเวลาแล้ว'); } else msg(r.message||'ไม่สำเร็จ',true);
    },
    async delSch(id){ if(!confirm('ลบเวลานี้?')) return; const r=await api('delete_schedule',null,{id}); if(r.status==='success'){S.sch=r.schedules;renderSch();} },
    async toggleSch(id){ const s=S.sch.find(x=>x.id===id); if(!s) return; const r=await api('save_schedule',null,{...s,action_type:s.action,enabled:s.enabled?0:1}); if(r.status==='success'){S.sch=r.schedules;renderSch();} },
    // calibration
    calRef(k){
      const ref=parseFloat($('aeRef_'+k).value), raw=parseFloat(S.raw[k]);
      if (isNaN(ref)||isNaN(raw)) { msg('ต้องมีค่าอ้างอิงและค่าดิบปัจจุบัน', true); return; }
      const g = parseFloat($('aeGain_'+k).value)||1;
      $('aeOff_'+k).value = (ref - raw*g).toFixed(2); this.calPreview();
    },
    calPreview(){
      CALS.forEach(k=>{ const raw=parseFloat(S.raw[k]); const o=parseFloat($('aeOff_'+k).value)||0, g=parseFloat($('aeGain_'+k).value)||1; $('aePrev_'+k).textContent = isNaN(raw)?'-':(raw*g+o).toFixed(2); });
    },
    async saveCal(){
      const c={}; CALS.forEach(k=>c[k]={offset:parseFloat($('aeOff_'+k).value)||0,gain:parseFloat($('aeGain_'+k).value)||1});
      const r=await api('save_calibration',null,{calibration:c}); if(r.status==='success'){S.cal=r.calibration;msg('บันทึกค่าชดเชยแล้ว');renderCal();} else msg(r.message||'ไม่สำเร็จ',true);
    },
    async resetCal(){ if(!confirm('คืนค่าชดเชยทั้งหมดเป็น 0 / ×1 ?')) return; const r=await api('save_calibration',null,{calibration:{}}); if(r.status==='success'){S.cal=r.calibration;renderCal();msg('คืนค่าเริ่มต้นแล้ว');} }
  };

  function renderSch(){
    $('aeSchList').innerHTML = S.sch.length ? S.sch.map(s=>'<div class="ae-card flex justify-between gap-2"><div><b>'+esc(s.time)+'</b> '+(s.action==='on'?'เปิด':'ปิด')+' '+esc(relayName(String(s.relay)))+(s.action==='on'&&s.duration>0?' '+s.duration+' นาที':'')+' <span class="ae-tag '+(s.enabled?'on':'')+'">'+(s.enabled?'เปิดใช้':'ปิดอยู่')+'</span><div class="ae-muted">'+esc(s.name||'')+' วัน '+(s.days.length===7?'ทุกวัน':s.days.map(d=>DAYS[d]).join(','))+'</div></div><div class="flex flex-col gap-1"><button class="ae-btn ghost" onclick="AE.toggleSch(\''+s.id+'\')">'+(s.enabled?'ปิด':'เปิด')+'</button><button class="ae-btn red" onclick="AE.delSch(\''+s.id+'\')">ลบ</button></div></div>').join('') : '<div class="ae-muted">ยังไม่มีตารางเวลา</div>';
  }
  function renderCal(){
    const active = CALS.some(k=>S.cal[k] && (Math.abs(S.cal[k].offset)>1e-9 || Math.abs(S.cal[k].gain-1)>1e-9));
    $('aeCalTag').textContent = active ? 'ใช้งานอยู่' : 'ไม่ได้ใช้'; $('aeCalTag').className = 'ae-tag ' + (active?'on':'');
    $('aeCal').innerHTML = CALS.map(k=>{ const c=S.cal[k]||{offset:0,gain:1}; const u=SENS[k][1];
      return '<div class="ae-card"><div class="flex justify-between"><b>'+SENS[k][0]+'</b><span class="ae-muted">ดิบ <span id="aeRaw_'+k+'">'+(S.raw[k]!=null?(+S.raw[k]).toFixed(2):'-')+'</span> → ใช้ <b id="aePrev_'+k+'" style="color:#6ee7b7">-</b> '+u+'</span></div>'
        +'<div class="ae-row ae-g3" style="margin-top:6px"><div><label>ค่าชดเชย (+/−)</label><input id="aeOff_'+k+'" type="number" step="any" value="'+c.offset+'" oninput="AE.calPreview()"></div>'
        +'<div><label>อัตราส่วน (0.5–2)</label><input id="aeGain_'+k+'" type="number" step="any" value="'+c.gain+'" oninput="AE.calPreview()"></div>'
        +'<div><label>ค่าอ้างอิงที่วัดได้จริง</label><div class="flex gap-1"><input id="aeRef_'+k+'" type="number" step="any"><button class="ae-btn" onclick="AE.calRef(\''+k+'\')">คำนวณ</button></div></div></div></div>'; }).join('');
    AE.calPreview();
  }

  $('aeMaster').onclick = () => AE.master();
  $('aeStopOn').onchange = e => { $('aeStopRow').style.display = e.target.checked ? 'grid' : 'none'; };

  async function load(){
    try {
      const [t, rl, sc, cl] = await Promise.all([api('get_telemetry'), api('get_rules'), api('get_schedules'), api('get_calibration')]);
      S.relays = t.relays || {};
      S.raw = (cl.raw) || {};
      S.rules = rl.rules || []; S.enabled = !!rl.enabled; S.rt = rl.runtime || {};
      S.sch = sc.schedules || []; S.cal = cl.calibration || {};
      renderRules(); renderSch(); renderCal();
    } catch(e){ msg('โหลดข้อมูลไม่สำเร็จ: '+e.message, true); }
  }
  load();
  setInterval(async()=>{ try{ const rl=await api('get_rules'); if(rl.status==='success' && $('aeForm').style.display==='none'){ S.rules=rl.rules; S.enabled=!!rl.enabled; S.rt=rl.runtime||{}; renderRules(); } }catch(e){} }, 15000);
})();
</script>
</section>
