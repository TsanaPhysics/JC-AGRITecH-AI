<?php
/**
 * LEQs-xAI Rules Add-on: โหมดอัตโนมัติตามเงื่อนไข + ค่าชดเชยเซนเซอร์
 * ไฟล์ข้อมูล: data/rules.json {enabled, rules[]}, data/calibration.json {sensor: {offset, gain}}
 * - ค่าชดเชยใช้ตอน "อ่าน" (corrected = raw*gain + offset) ค่าดิบใน state ไม่ถูกแก้ จึงย้อนกลับได้
 * - VPD/จุดน้ำค้างคำนวณใหม่จากอุณหภูมิและความชื้นที่ชดเชยแล้ว
 */
if (!function_exists('rules_sensor_list')) {

    function rules_sensor_list() {
        return [
            'soil_moisture' => ['ความชื้นดิน', '%'],
            'temperature' => ['อุณหภูมิอากาศ', '°C'],
            'humidity' => ['ความชื้นสัมพัทธ์อากาศ', '%'],
            'vpd' => ['VPD', 'kPa'],
            'soil_ph' => ['pH ดิน', ''],
            'soil_ec' => ['EC ดิน', 'µS/cm'],
            'soil_temperature' => ['อุณหภูมิดิน', '°C'],
        ];
    }
    function rules_cal_sensors() { return ['temperature', 'humidity', 'soil_moisture', 'soil_ph', 'soil_ec', 'soil_temperature']; }

    // ---------------- Calibration ----------------
    function rules_get_cal($data_dir) {
        $c = auto_read_json($data_dir . '/calibration.json', []);
        $out = [];
        foreach (rules_cal_sensors() as $k) {
            $o = floatval($c[$k]['offset'] ?? 0);
            $g = floatval($c[$k]['gain'] ?? 1);
            if ($g <= 0) $g = 1;
            $out[$k] = ['offset' => $o, 'gain' => $g];
        }
        return $out;
    }
    function rules_save_cal($data_dir, $in) {
        $out = [];
        foreach (rules_cal_sensors() as $k) {
            $o = floatval($in[$k]['offset'] ?? 0);
            $g = floatval($in[$k]['gain'] ?? 1);
            if (!is_finite($o) || abs($o) > 100) $o = 0;
            if (!is_finite($g) || $g < 0.5 || $g > 2.0) $g = 1;
            $out[$k] = ['offset' => round($o, 3), 'gain' => round($g, 4)];
        }
        auto_write_json($data_dir . '/calibration.json', $out);
        return $out;
    }
    function rules_cal_active($cal) {
        foreach ($cal as $c) { if (abs($c['offset']) > 1e-9 || abs($c['gain'] - 1) > 1e-9) return true; }
        return false;
    }
    /** คืนสำเนา sensors ที่ชดเชยแล้ว พร้อมคำนวณค่าที่เกี่ยวข้องใหม่ */
    function rules_apply_cal($sensors, $cal) {
        $s = $sensors;
        foreach ($cal as $k => $c) {
            if (isset($s[$k]) && is_numeric($s[$k])) {
                $v = floatval($s[$k]) * $c['gain'] + $c['offset'];
                if ($k === 'humidity' || $k === 'soil_moisture') $v = max(0, min(100, $v));
                if ($k === 'soil_ph') $v = max(0, min(14, $v));
                $s[$k] = round($v, 2);
            }
        }
        $touched = (abs($cal['temperature']['offset'] ?? 0) > 1e-9 || abs(($cal['temperature']['gain'] ?? 1) - 1) > 1e-9
            || abs($cal['humidity']['offset'] ?? 0) > 1e-9 || abs(($cal['humidity']['gain'] ?? 1) - 1) > 1e-9);
        if ($touched && isset($s['temperature'], $s['humidity']) && is_numeric($s['temperature']) && is_numeric($s['humidity'])) {
            $t = floatval($s['temperature']); $rh = floatval($s['humidity']);
            $es = 0.6108 * exp(17.27 * $t / ($t + 237.3));
            $s['vpsat'] = round($es, 2);
            $s['vpact'] = round($es * $rh / 100.0, 2);
            $s['vpd'] = round($es * (1 - $rh / 100.0), 2);
            $s['temperature_f'] = round($t * 1.8 + 32, 2);
            if ($rh > 0) {
                $g = (17.27 * $t) / (237.3 + $t) + log($rh / 100.0);
                $dp = 237.3 * $g / (17.27 - $g);
                $s['dew_point'] = round($dp, 2);
                $s['dew_margin'] = round($t - $dp, 2);
            }
        }
        return $s;
    }
    function rules_corrected_state($state, $data_dir) {
        $cal = rules_get_cal($data_dir);
        if (!rules_cal_active($cal)) return $state;
        $state['sensors_raw'] = $state['sensors'] ?? [];
        $state['sensors'] = rules_apply_cal($state['sensors'] ?? [], $cal);
        return $state;
    }

    // ---------------- Rules store ----------------
    function rules_get($data_dir) {
        $d = auto_read_json($data_dir . '/rules.json', []);
        $rules = array_values(array_filter($d['rules'] ?? [], 'is_array'));
        return ['enabled' => !empty($d['enabled']), 'rules' => $rules];
    }
    function rules_save($data_dir, $d) { auto_write_json($data_dir . '/rules.json', $d); }

    function rules_clean_cond($c) {
        $sensors = rules_sensor_list();
        $sensor = strval($c['sensor'] ?? '');
        $op = strval($c['op'] ?? '');
        if (!isset($sensors[$sensor]) || !in_array($op, ['<', '<=', '>', '>='], true) || !isset($c['value']) || !is_numeric($c['value'])) return null;
        return ['sensor' => $sensor, 'op' => $op, 'value' => round(floatval($c['value']), 3)];
    }
    function rules_clean($in, $existing_id = null) {
        $relay = intval($in['relay'] ?? 0);
        if ($relay < 1 || $relay > 4) return [null, 'หมายเลขรีเลย์ต้องเป็น 1-4'];
        $conds = [];
        foreach ((array)($in['conditions'] ?? []) as $c) {
            $cc = is_array($c) ? rules_clean_cond($c) : null;
            if ($cc) $conds[] = $cc;
        }
        if (count($conds) < 1 || count($conds) > 4) return [null, 'ต้องมีเงื่อนไข 1-4 ข้อ'];
        $action = (($in['action'] ?? 'on') === 'off') ? 'off' : 'on';
        $stop = (isset($in['stop']) && is_array($in['stop'])) ? rules_clean_cond($in['stop']) : null;
        $dur = max(0, min(720, intval($in['duration'] ?? 0)));
        if ($action === 'on' && $dur === 0 && !$stop) return [null, 'การสั่งเปิดต้องกำหนดระยะเวลา หรือเงื่อนไขหยุด เพื่อไม่ให้เปิดค้าง'];
        $win = null;
        if (!empty($in['window']) && is_array($in['window'])) {
            $a = strval($in['window']['start'] ?? ''); $b = strval($in['window']['end'] ?? '');
            if (preg_match('/^([01]?\d|2[0-3]):[0-5]\d$/', $a) && preg_match('/^([01]?\d|2[0-3]):[0-5]\d$/', $b)) {
                $win = ['start' => sprintf('%02d:%02d', intval(substr($a, 0, strpos($a, ':'))), intval(substr($a, -2))),
                        'end' => sprintf('%02d:%02d', intval(substr($b, 0, strpos($b, ':'))), intval(substr($b, -2)))];
            }
        }
        $days = $in['days'] ?? [0, 1, 2, 3, 4, 5, 6];
        if (is_string($days)) $days = array_filter(explode(',', $days), 'strlen');
        $days = array_values(array_unique(array_filter(array_map('intval', (array)$days), function ($d) { return $d >= 0 && $d <= 6; })));
        sort($days);
        if (!$days) return [null, 'ต้องเลือกอย่างน้อย 1 วัน'];
        $en = $in['enabled'] ?? 1;
        return [[
            'id' => $existing_id ?: ('r' . substr(md5(uniqid('', true)), 0, 8)),
            'name' => mb_substr(trim(strval($in['name'] ?? '')), 0, 60),
            'enabled' => ($en === true || $en === 1 || $en === '1' || $en === 'true') ? 1 : 0,
            'relay' => $relay,
            'action' => $action,
            'logic' => (($in['logic'] ?? 'all') === 'any') ? 'any' : 'all',
            'conditions' => $conds,
            'stop' => $stop,
            'duration' => $dur,
            'hold_sec' => max(0, min(3600, intval($in['hold_sec'] ?? 30))),
            'cooldown_min' => max(0, min(720, intval($in['cooldown_min'] ?? 10))),
            'window' => $win,
            'days' => $days,
        ], null];
    }

    // ---------------- Evaluate ----------------
    function rules_cmp($v, $op, $x) {
        if ($v === null) return false;
        switch ($op) { case '<': return $v < $x; case '<=': return $v <= $x; case '>': return $v > $x; case '>=': return $v >= $x; }
        return false;
    }
    function rules_in_window($win, $days, $dt) {
        if (!in_array(intval($dt->format('w')), array_map('intval', $days), true)) return false;
        if (!$win) return true;
        $m = intval($dt->format('H')) * 60 + intval($dt->format('i'));
        $a = intval(substr($win['start'], 0, 2)) * 60 + intval(substr($win['start'], 3, 2));
        $b = intval(substr($win['end'], 0, 2)) * 60 + intval(substr($win['end'], 3, 2));
        if ($a === $b) return true;
        return $a < $b ? ($m >= $a && $m < $b) : ($m >= $a || $m < $b);
    }
    function rules_needs_eval($state, $data_dir) {
        if (($state['rules_last_eval'] ?? 0) > time() - 5) return false;
        $d = rules_get($data_dir);
        if (!$d['enabled']) return false;
        foreach ($d['rules'] as $r) { if (!empty($r['enabled'])) return true; }
        return false;
    }
    /** ต้องเรียกภายใต้ล็อกสถานะ คืน true ถ้าสถานะเปลี่ยน */
    function rules_eval(&$state, $data_dir) {
        $now = time();
        $state['rules_last_eval'] = $now;
        $changed = true;
        $d = rules_get($data_dir);
        if (!$d['enabled']) return $changed;
        $last = intval($state['board']['last_direct_post_time'] ?? 0);
        if ($last <= 0 || ($now - $last) > 60) return $changed; // บอร์ดออฟไลน์ ห้ามตัดสินใจจากค่าเก่า
        $sens = rules_apply_cal($state['sensors'] ?? [], rules_get_cal($data_dir));
        $val = function ($k) use ($sens) { return (isset($sens[$k]) && is_numeric($sens[$k])) ? floatval($sens[$k]) : null; };
        $dt = auto_now();
        foreach ($d['rules'] as $r) {
            if (empty($r['enabled'])) continue;
            $id = $r['id']; $rid = strval($r['relay']);
            if (!isset($state['relays'][$rid])) continue;
            $rt = $state['rule_rt'][$id] ?? ['since' => null, 'last_fire' => 0, 'on_by' => false];
            $cur = intval($state['relays'][$rid]['state'] ?? 0);
            $label = $r['name'] !== '' ? $r['name'] : $id;

            if (!empty($rt['on_by'])) {
                if ($cur === 0) { $rt['on_by'] = false; }
                elseif (!empty($r['stop']) && rules_cmp($val($r['stop']['sensor']), $r['stop']['op'], $r['stop']['value'])) {
                    auto_set_relay($state, $rid, 0);
                    unset($state['timers'][$rid]);
                    $rt['on_by'] = false;
                    auto_audit($data_dir, 'rule_stop', 'กฎ "' . $label . '": ' . auto_relay_name($state, $rid) . ' ปิด เพราะถึงเงื่อนไขหยุด', 'rule');
                    $cur = 0;
                }
            }

            $results = [];
            foreach ($r['conditions'] as $c) { $results[] = rules_cmp($val($c['sensor']), $c['op'], $c['value']); }
            $ok = ($r['logic'] === 'any') ? in_array(true, $results, true) : !in_array(false, $results, true);
            $ok = $ok && rules_in_window($r['window'] ?? null, $r['days'] ?? [], $dt);
            if ($ok) { if (empty($rt['since'])) $rt['since'] = $now; } else { $rt['since'] = null; }

            $want = ($r['action'] === 'on') ? 1 : 0;
            if ($ok && !empty($rt['since']) && ($now - $rt['since']) >= intval($r['hold_sec'])
                && ($now - intval($rt['last_fire'])) >= intval($r['cooldown_min']) * 60 && $cur !== $want) {
                auto_set_relay($state, $rid, $want);
                if ($want === 1 && intval($r['duration']) > 0) $state['timers'][$rid] = ['end' => $now + intval($r['duration']) * 60];
                else unset($state['timers'][$rid]);
                $rt['last_fire'] = $now;
                $rt['on_by'] = ($want === 1);
                $desc = [];
                foreach ($r['conditions'] as $c) { $desc[] = $c['sensor'] . ' ' . $c['op'] . ' ' . $c['value'] . ' (ค่าปัจจุบัน ' . (($v = $val($c['sensor'])) === null ? '-' : round($v, 2)) . ')'; }
                auto_audit($data_dir, 'rule', 'กฎ "' . $label . '": ' . auto_relay_name($state, $rid) . ($want ? ' เปิด' : ' ปิด') . ' เมื่อ ' . implode($r['logic'] === 'any' ? ' หรือ ' : ' และ ', $desc), 'rule');
            }
            $state['rule_rt'][$id] = $rt;
        }
        return $changed;
    }
}
