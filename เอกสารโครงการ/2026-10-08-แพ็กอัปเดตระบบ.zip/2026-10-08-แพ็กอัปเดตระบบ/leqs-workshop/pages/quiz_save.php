<?php
/**
 * บันทึกผลแบบทดสอบ Pre/Post ลง data/quiz_results.json
 *  POST JSON {mode, name, group, score, total, topics}
 *  GET  ?export=csv  ดาวน์โหลดผลทั้งหมด (ถ้ามี data/api_key.txt ต้องแนบ ?key= หรือหัว X-Api-Key)
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$dir = __DIR__ . '/../data';
$file = $dir . '/quiz_results.json';
$kf = $dir . '/api_key.txt';
$key = is_file($kf) ? trim((string)@file_get_contents($kf)) : '';

function qs_read($f) { $d = json_decode((string)@file_get_contents($f), true); return is_array($d) ? $d : []; }

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (($_GET['export'] ?? '') !== 'csv') { echo json_encode(['status' => 'error', 'message' => 'ใช้ ?export=csv']); exit; }
    $given = $_SERVER['HTTP_X_API_KEY'] ?? ($_GET['key'] ?? '');
    if ($key !== '' && !hash_equals($key, (string)$given)) { http_response_code(401); echo json_encode(['status' => 'error', 'message' => 'ต้องใช้ API key']); exit; }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="quiz_results.csv"');
    echo "\xEF\xBB\xBF" . "time,mode,name,group,score,total,percent\n";
    foreach (qs_read($file) as $r) {
        $name = str_replace('"', '""', (string)($r['name'] ?? ''));
        if ($name !== '' && strpos('=+-@', $name[0]) !== false) { $name = "'" . $name; }   // กัน CSV injection
        echo implode(',', [$r['time'] ?? '', $r['mode'] ?? '', '"' . $name . '"', $r['group'] ?? '', $r['score'] ?? '', $r['total'] ?? '', $r['percent'] ?? '']) . "\n";
    }
    exit;
}

$in = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($in)) { echo json_encode(['status' => 'error', 'message' => 'ข้อมูลไม่ถูกต้อง']); exit; }
$mode = (($in['mode'] ?? '') === 'post') ? 'post' : 'pre';
$name = mb_substr(trim((string)($in['name'] ?? '')), 0, 80);
$total = intval($in['total'] ?? 0); $score = intval($in['score'] ?? -1);
if ($name === '' || $total < 1 || $total > 100 || $score < 0 || $score > $total) { echo json_encode(['status' => 'error', 'message' => 'ข้อมูลไม่ครบหรือไม่สมเหตุสมผล']); exit; }
$g = intval($in['group'] ?? 0);
$rec = ['time' => date('Y-m-d H:i:s'), 'mode' => $mode, 'name' => $name, 'group' => ($g >= 1 && $g <= 10) ? $g : '', 'score' => $score, 'total' => $total, 'percent' => round($score * 100 / $total, 1)];
@mkdir($dir, 0775, true);
$fp = @fopen($dir . '/quiz.lock', 'c');
if ($fp) { flock($fp, LOCK_EX); }
$all = qs_read($file);
if (count($all) >= 5000) { echo json_encode(['status' => 'error', 'message' => 'บันทึกเต็ม']); exit; }
$all[] = $rec;
$ok = @file_put_contents($file, json_encode($all, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
if ($fp) { flock($fp, LOCK_UN); fclose($fp); }
echo json_encode($ok === false ? ['status' => 'error', 'message' => 'เขียนไฟล์ไม่ได้ (ตรวจสิทธิ์โฟลเดอร์ data/)'] : ['status' => 'success']);
