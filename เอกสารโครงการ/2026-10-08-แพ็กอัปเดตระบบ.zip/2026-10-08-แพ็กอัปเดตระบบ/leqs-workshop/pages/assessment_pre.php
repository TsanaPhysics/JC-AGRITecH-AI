<?php
/**
 * LEQs-xAI Pre-test Assessment Portal
 */
$page_title = "แบบทดสอบก่อนเรียน (Pre-test) | LEQs-xAI";
?>
<!DOCTYPE html>
<html lang="th" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&family=Kanit:wght@400;600;700&family=Chakra+Petch:wght@500;600;700&family=Orbitron:wght@600;700;900&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex flex-col justify-between hero-pattern">

    <!-- Top Navbar -->
    <nav class="bg-slate-900/90 backdrop-blur-xl border-b border-slate-800 py-3.5 px-4 sm:px-6 fixed w-full top-0 z-50">
        <div class="max-w-4xl mx-auto flex items-center justify-between">
            <a href="../index.php" class="flex items-center gap-2.5 sm:gap-3">
                <div class="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-slate-800 border border-cyan-500/40 flex items-center justify-center text-cyan-400 font-tech font-bold text-lg sm:text-xl shrink-0">
                    L
                </div>
                <div>
                    <div class="font-tech text-sm sm:text-base font-black text-white">LEQs-xAI</div>
                    <div class="text-[9px] sm:text-[10px] text-slate-400">แบบทดสอบวัดความรู้ก่อนเรียน</div>
                </div>
            </a>
            <a href="../index.php" class="px-3 sm:px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs transition flex items-center gap-1.5" title="กลับหน้าหลัก">
                <i class="fa-solid fa-arrow-left"></i> <span class="hidden sm:inline">หน้าหลัก</span>
            </a>
        </div>
    </nav>

    <!-- Quiz Content -->
    <main class="pt-24 sm:pt-32 pb-20 px-3 sm:px-4 max-w-3xl mx-auto w-full">
        <div class="p-5 sm:p-10 rounded-2xl sm:rounded-3xl bg-slate-900/95 border border-slate-800 shadow-2xl backdrop-blur-xl">
            
            <div class="text-center mb-6 sm:mb-8">
                <span class="px-3.5 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10px] sm:text-xs font-bold uppercase tracking-wider">
                    Pre-training Assessment
                </span>
                <h1 class="text-xl sm:text-3xl font-black text-white font-heading mt-2">
                    แบบทดสอบก่อนเรียน: LEQs-xAI
                </h1>
                <p class="text-xs sm:text-sm text-slate-400 mt-2">
                    วัดความรู้พื้นฐานด้านเซนเซอร์ IoT, VPD, Edge AI, Computer Vision, xAI และระบบควบคุมอัตโนมัติ (32 ข้อ)
                </p>
            </div>

            <?php $QUIZ_MODE = 'pre'; include __DIR__ . '/../includes/quiz_core.php'; ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-slate-950 border-t border-slate-900 py-6 text-center text-xs text-slate-500">
        LEQs-xAI Assessment System © 2026 มหาวิทยาลัยราชภัฏรำไพพรรณี
    </footer>

</body>
</html>
